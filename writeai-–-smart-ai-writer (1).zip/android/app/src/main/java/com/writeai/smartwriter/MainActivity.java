package com.writeai.smartwriter;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
