/**
 * Server-Side User Entitlement & Usage Control
 *
 * Enforces server-side limits preventing client-side spoofing or reinstall tampering.
 * Limits:
 * - TRIAL_DAILY_LIMIT = 20
 * - FREE_DAILY_LIMIT = 3
 * - PREMIUM_DAILY_LIMIT = 150 (fair-use)
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

export interface ServerUserRecord {
  userId: string;
  createdAt: number;
  trialStartDate: number;
  trialEndDate: number;
  status: 'TRIAL_ACTIVE' | 'TRIAL_EXPIRED' | 'PREMIUM_ACTIVE' | 'FREE_LIMITED';
  isPremium: boolean;
  premiumExpiryDate?: number;
  planId?: 'monthly' | 'yearly';
  dailyUsageDate: string;
  generationsCount: number;
  bonusGenerations: number;
}

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export const SERVER_LIMITS = {
  TRIAL_DAILY_LIMIT: 20,
  FREE_DAILY_LIMIT: 3,
  PREMIUM_DAILY_LIMIT: 150,
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const DATA_FILE = path.join(DATA_DIR, 'entitlements.json');

// File-backed persistent user store
const userStore = new Map<string, ServerUserRecord>();

function loadFromDisk(): void {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) {
        for (const record of data) {
          if (record && record.userId) {
            userStore.set(record.userId, record);
          }
        }
      }
    }
  } catch (err) {
    console.error('Failed to load user entitlements from disk:', err);
  }
}

function saveToDisk(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const arr = Array.from(userStore.values());
    fs.writeFileSync(DATA_FILE, JSON.stringify(arr, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save user entitlements to disk:', err);
  }
}

// Initial load
loadFromDisk();

function getTodayString(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(
    d.getUTCDate()
  ).padStart(2, '0')}`;
}

export class EntitlementService {
  static getOrCreateUser(userId: string, clientTrialStart?: number): ServerUserRecord {
    const today = getTodayString();
    let record = userStore.get(userId);
    const now = Date.now();

    if (!record) {
      // Determine legitimate trial start date (use client's first install date if valid and older, else now)
      const startDate =
        typeof clientTrialStart === 'number' && clientTrialStart > 0 && clientTrialStart <= now
          ? clientTrialStart
          : now;

      record = {
        userId,
        createdAt: now,
        trialStartDate: startDate,
        trialEndDate: startDate + THIRTY_DAYS_MS,
        status: now >= startDate + THIRTY_DAYS_MS ? 'FREE_LIMITED' : 'TRIAL_ACTIVE',
        isPremium: false,
        dailyUsageDate: today,
        generationsCount: 0,
        bonusGenerations: 0,
      };
      userStore.set(userId, record);
      saveToDisk();
      return record;
    }

    // Reset daily counter if day changed
    if (record.dailyUsageDate !== today) {
      record.dailyUsageDate = today;
      record.generationsCount = 0;
      record.bonusGenerations = 0;
    }

    // Recompute subscription and trial status
    if (record.isPremium) {
      if (record.premiumExpiryDate && now > record.premiumExpiryDate) {
        record.isPremium = false;
        record.status = now >= record.trialEndDate ? 'FREE_LIMITED' : 'TRIAL_ACTIVE';
        record.premiumExpiryDate = undefined;
      } else {
        record.status = 'PREMIUM_ACTIVE';
      }
    } else {
      if (now >= record.trialEndDate) {
        record.status = 'FREE_LIMITED';
      } else {
        record.status = 'TRIAL_ACTIVE';
      }
    }

    userStore.set(userId, record);
    saveToDisk();
    return record;
  }

  static getDailyLimit(record: ServerUserRecord): number {
    if (record.status === 'PREMIUM_ACTIVE') {
      return SERVER_LIMITS.PREMIUM_DAILY_LIMIT;
    }
    if (record.status === 'TRIAL_ACTIVE') {
      return SERVER_LIMITS.TRIAL_DAILY_LIMIT;
    }
    return SERVER_LIMITS.FREE_DAILY_LIMIT;
  }

  static getGenerationsRemaining(record: ServerUserRecord): number {
    const limit = this.getDailyLimit(record);
    const totalAllowed = limit + (record.bonusGenerations || 0);
    return Math.max(0, totalAllowed - record.generationsCount);
  }

  static canGenerate(userId: string): { allowed: boolean; remaining: number; reason?: string } {
    const record = this.getOrCreateUser(userId);
    const remaining = this.getGenerationsRemaining(record);

    if (remaining <= 0) {
      return {
        allowed: false,
        remaining: 0,
        reason:
          record.status === 'TRIAL_ACTIVE'
            ? `Daily trial limit (${SERVER_LIMITS.TRIAL_DAILY_LIMIT}/day) reached. Watch a rewarded ad for +1 or upgrade to Premium.`
            : `Daily free limit (${SERVER_LIMITS.FREE_DAILY_LIMIT}/day) reached. Watch a rewarded ad for +1 or unlock WriteAI Premium.`,
      };
    }

    return { allowed: true, remaining };
  }

  static recordGeneration(userId: string): { success: boolean; remaining: number } {
    const check = this.canGenerate(userId);
    if (!check.allowed) {
      return { success: false, remaining: 0 };
    }
    const record = this.getOrCreateUser(userId);
    record.generationsCount += 1;
    userStore.set(userId, record);
    saveToDisk();
    return { success: true, remaining: this.getGenerationsRemaining(record) };
  }

  static grantRewardedAdBonus(userId: string): { remaining: number } {
    const record = this.getOrCreateUser(userId);
    // Rewarded ads only apply to trial and free users
    if (!record.isPremium) {
      record.bonusGenerations = (record.bonusGenerations || 0) + 1;
      userStore.set(userId, record);
      saveToDisk();
    }
    return { remaining: this.getGenerationsRemaining(record) };
  }

  static setPremium(userId: string, expiryDate: number, planId: 'monthly' | 'yearly'): void {
    const record = this.getOrCreateUser(userId);
    record.isPremium = true;
    record.status = 'PREMIUM_ACTIVE';
    record.premiumExpiryDate = expiryDate;
    record.planId = planId;
    userStore.set(userId, record);
    saveToDisk();
  }

  static revokePremium(userId: string): void {
    const record = this.getOrCreateUser(userId);
    record.isPremium = false;
    record.status = Date.now() >= record.trialEndDate ? 'FREE_LIMITED' : 'TRIAL_ACTIVE';
    record.premiumExpiryDate = undefined;
    userStore.set(userId, record);
    saveToDisk();
  }

  // Developer simulation helper for testing
  static simulateUserTrialDays(userId: string, daysLeft: number): ServerUserRecord {
    const record = this.getOrCreateUser(userId);
    const now = Date.now();
    record.trialEndDate = now + daysLeft * 24 * 60 * 60 * 1000;
    record.isPremium = false;
    record.status = daysLeft > 0 ? 'TRIAL_ACTIVE' : 'FREE_LIMITED';
    userStore.set(userId, record);
    saveToDisk();
    return record;
  }
}
