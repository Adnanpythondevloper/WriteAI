import { GoogleGenAI } from '@google/genai';
import { EntitlementService } from './entitlementHandler.ts';

export interface GenerateApiPayload {
  userId?: string;
  toolId: string;
  title: string;
  inputs: Record<string, string>;
  tone: string;
  length: string;
  language: string;
  systemPromptGoal?: string;
}

export async function handleGenerateRequest(payload: GenerateApiPayload): Promise<{ text: string; remaining?: number }> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured on the server. Please set your Gemini API key in the environment.'
    );
  }

  const { userId, toolId, title, inputs, tone, length, language, systemPromptGoal } = payload;

  // Server-side entitlement and rate-limit guard
  if (userId) {
    const check = EntitlementService.canGenerate(userId);
    if (!check.allowed) {
      const err: any = new Error(check.reason || 'Server-side daily AI generation limit reached.');
      err.status = 429;
      throw err;
    }
  }

  if (!inputs || Object.keys(inputs).length === 0) {
    throw new Error('Input content cannot be empty.');
  }

  // Construct structured prompt
  let lengthGuidance = 'balanced length (~150-300 words)';
  if (length === 'Short') {
    lengthGuidance = 'concise and punchy (~60-120 words)';
  } else if (length === 'Long') {
    lengthGuidance = 'thorough, detailed, and comprehensive (~400-800 words)';
  }

  const inputDetails = Object.entries(inputs)
    .filter(([_, v]) => typeof v === 'string' && v.trim().length > 0)
    .map(([k, v]) => `${k.toUpperCase()}: ${v}`)
    .join('\n');

  const systemInstruction = `You are WriteAI, an elite AI writing assistant powering a production Android application.
Target Language: Write the generated content exclusively in ${language || 'English'} (while maintaining standard English loan words or industry jargon where appropriate).
Desired Tone: ${tone || 'Professional'}.
Length: ${lengthGuidance}.
Specific Tool Goal: ${systemPromptGoal || 'Generate exceptional, publication-ready copy.'}

CRITICAL RULES:
1. If the tool is CV / Resume Writer or Cover Letter Writer: NEVER invent or hallucinate qualifications, degrees, companies, employment dates, or achievements that the user did not explicitly state. Base all bullet points strictly on the user's provided input.
2. For Social Media Writer: Produce realistic format suited for the platform (hashtags, spacing, hooks).
3. For Blog Writer: Include an SEO Title, Meta Description, Headings (H2/H3), full cohesive article paragraphs, and a Conclusion.
4. Output cleanly formatted Markdown text ready for an Android mobile text editor. Do NOT wrap output in generic meta-commentary like "Here is your email:". Start directly with the written content.`;

  const userPrompt = `Tool: ${toolId}
Task: ${title}

USER INPUT DATA:
${inputDetails}

Write the final copy now adhering to all instructions.`;

  const ai = new GoogleGenAI({ apiKey });

  const modelsToTry = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: userPrompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const responseText = response.text || '';
      if (responseText.trim()) {
        let remaining: number | undefined;
        if (userId) {
          const rec = EntitlementService.recordGeneration(userId);
          remaining = rec.remaining;
        }
        return { text: responseText.trim(), remaining };
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || String(err);
      console.warn(`Model ${model} returned error, falling back to next available model...`, errMsg);
      continue;
    }
  }

  // Parse clean error message
  let cleanMsg = lastError?.message || 'AI service temporarily unavailable. Please try again.';
  try {
    const parsed = JSON.parse(cleanMsg);
    if (parsed.error?.message) {
      cleanMsg = parsed.error.message;
    }
  } catch {
    // Already plain text
  }

  throw new Error(cleanMsg);
}
