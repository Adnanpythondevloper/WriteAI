import React, { useState, useEffect, useCallback } from 'react';
import { ToolConfig } from './config/tools.config';
import { HistoryItem, TrialStatus, UserSettings } from './types';
import { StorageManager } from './services/StorageManager';
import { TrialManager } from './services/TrialManager';
import { UsageManager } from './services/UsageManager';
import { HistoryManager } from './services/HistoryManager';
import { BillingManager } from './services/BillingManager';
import { AdsManager } from './services/AdsManager';

import { Header } from './components/common/Header';
import { BottomNav, TabType } from './components/common/BottomNav';
import { Toast, ToastMessage } from './components/common/Toast';

import { HomeScreen } from './components/screens/HomeScreen';
import { ToolFormScreen } from './components/screens/ToolFormScreen';
import { OutputScreen } from './components/screens/OutputScreen';
import { HistoryScreen } from './components/screens/HistoryScreen';
import { FavoritesScreen } from './components/screens/FavoritesScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { OnboardingScreen } from './components/screens/OnboardingScreen';

import { PremiumPaywallModal } from './components/modals/PremiumPaywallModal';
import { LimitReachedModal } from './components/modals/LimitReachedModal';
import { RewardedAdModal } from './components/modals/RewardedAdModal';
import { InterstitialAdModal } from './components/modals/InterstitialAdModal';
import { PublishingChecklistModal } from './components/modals/PublishingChecklistModal';
import {
  PrivacyPolicyModal,
  TermsOfServiceModal,
  ContactSupportModal,
} from './components/modals/LegalModals';

export default function App() {
  // App State
  const [settings, setSettings] = useState<UserSettings>(() =>
    StorageManager.getSettings()
  );
  const [trialStatus, setTrialStatus] = useState<TrialStatus>(() => {
    const s = StorageManager.getTrialState();
    return s?.status || 'TRIAL_ACTIVE';
  });
  const [daysRemaining, setDaysRemaining] = useState<number>(() => {
    return TrialManager.getDaysRemaining();
  });
  const [generationsRemaining, setGenerationsRemaining] = useState<number>(() => {
    return UsageManager.getGenerationsRemaining();
  });
  const [activeTab, setActiveTab] = useState<TabType>('home');

  // Navigation flow
  const [selectedTool, setSelectedTool] = useState<ToolConfig | null>(null);
  const [activeOutputItem, setActiveOutputItem] = useState<HistoryItem | null>(null);
  const [recentHistory, setRecentHistory] = useState<HistoryItem[]>([]);
  const [favorites, setFavorites] = useState<HistoryItem[]>([]);

  // Modals & Popups
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [showPaywall, setShowPaywall] = useState(false);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [showRewardedAd, setShowRewardedAd] = useState(false);
  const [showInterstitialAd, setShowInterstitialAd] = useState(false);
  const [showChecklist, setShowChecklist] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showSupport, setShowSupport] = useState(false);

  // Android phone mockup frame toggle
  const [isDeviceFrameActive, setIsDeviceFrameActive] = useState(false);

  const showToast = useCallback(
    (message: string, type: 'success' | 'error' | 'info' = 'info') => {
      setToast({
        id: String(Date.now()),
        type,
        message,
      });
    },
    []
  );

  const refreshAppState = useCallback(() => {
    TrialManager.recomputeStatus();
    const trial = TrialManager.getState();
    setTrialStatus(trial.status);
    setDaysRemaining(TrialManager.getDaysRemaining());
    setGenerationsRemaining(UsageManager.getGenerationsRemaining());
    setRecentHistory(HistoryManager.getAll());
    setFavorites(HistoryManager.getFavorites());
  }, []);

  // Initialize trial, Mobile Ads SDK & listen to billing and entitlement updates
  useEffect(() => {
    TrialManager.initialize();
    AdsManager.initialize();
    refreshAppState();

    const unsubBilling = BillingManager.subscribe(() => {
      refreshAppState();
    });

    const unsubTrial = TrialManager.subscribe(() => {
      refreshAppState();
    });

    return () => {
      unsubBilling();
      unsubTrial();
    };
  }, [refreshAppState]);

  // Handle Dark mode class
  useEffect(() => {
    const isDark =
      settings.darkMode === 'dark' ||
      (settings.darkMode === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  const handleOnboardingComplete = () => {
    const updated = { ...settings, hasCompletedOnboarding: true };
    StorageManager.saveSettings(updated);
    setSettings(updated);
    showToast('Welcome to WriteAI! Your 30-day free trial has begun.', 'success');
  };

  const handleRewardedAdBonusEarned = async () => {
    const newRemaining = await AdsManager.grantRewardedAdBonus();
    setGenerationsRemaining(newRemaining);
    showToast('+1 Free Generation Earned!', 'success');
  };

  const handleCheckAndShowInterstitial = () => {
    if (AdsManager.shouldShowInterstitial()) {
      AdsManager.recordInterstitialShown();
      setShowInterstitialAd(true);
    }
  };

  const handleBackToHomeOrList = () => {
    setSelectedTool(null);
    setActiveOutputItem(null);
    refreshAppState();
    handleCheckAndShowInterstitial();
  };

  // Render Onboarding if first launch
  if (!settings.hasCompletedOnboarding) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  const isPremium = trialStatus === 'PREMIUM_ACTIVE';

  // Screen content router
  const renderScreenContent = () => {
    if (activeOutputItem) {
      return (
        <OutputScreen
          item={activeOutputItem}
          isPremium={isPremium}
          onBack={handleBackToHomeOrList}
          onRegenerate={() => {
            if (selectedTool) {
              setActiveOutputItem(null);
            } else {
              showToast('Opening generation form...', 'info');
              handleBackToHomeOrList();
            }
          }}
          onShowToast={showToast}
        />
      );
    }

    if (selectedTool) {
      return (
        <ToolFormScreen
          tool={selectedTool}
          defaultTone={settings.defaultTone}
          defaultLength={settings.defaultLength}
          defaultLanguage={settings.defaultLanguage}
          onBack={handleBackToHomeOrList}
          onGenerationComplete={item => {
            setActiveOutputItem(item);
            refreshAppState();
          }}
          onLimitReached={() => setShowLimitModal(true)}
          onShowToast={showToast}
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <HomeScreen
            trialStatus={trialStatus}
            daysRemaining={daysRemaining}
            generationsRemaining={generationsRemaining}
            recentHistory={recentHistory}
            favorites={favorites}
            onSelectTool={tool => setSelectedTool(tool)}
            onOpenHistoryItem={item => setActiveOutputItem(item)}
            onOpenPaywall={() => setShowPaywall(true)}
            onOpenUsageModal={() => setShowLimitModal(true)}
            onWatchRewardedAd={() => setShowRewardedAd(true)}
            onNavigateTab={tab => setActiveTab(tab)}
          />
        );

      case 'history':
        return (
          <HistoryScreen
            onOpenItem={item => setActiveOutputItem(item)}
            onRefresh={refreshAppState}
            onShowToast={showToast}
          />
        );

      case 'favorites':
        return (
          <FavoritesScreen
            onOpenItem={item => setActiveOutputItem(item)}
            onRefresh={refreshAppState}
            onShowToast={showToast}
          />
        );

      case 'settings':
        return (
          <SettingsScreen
            settings={settings}
            trialStatus={trialStatus}
            daysRemaining={daysRemaining}
            onUpdateSettings={setSettings}
            onOpenPaywall={() => setShowPaywall(true)}
            onShowPrivacy={() => setShowPrivacy(true)}
            onShowTerms={() => setShowTerms(true)}
            onShowSupport={() => setShowSupport(true)}
            onShowChecklist={() => setShowChecklist(true)}
            onRefreshAppState={refreshAppState}
            onShowToast={showToast}
          />
        );
    }
  };

  const appView = (
    <div className="flex flex-col min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors">
      <Header
        trialStatus={trialStatus}
        daysRemaining={daysRemaining}
        generationsRemaining={generationsRemaining}
        onOpenPaywall={() => setShowPaywall(true)}
        onOpenUsageModal={() => setShowLimitModal(true)}
        isDeviceFrameActive={isDeviceFrameActive}
        onToggleDeviceFrame={() => setIsDeviceFrameActive(!isDeviceFrameActive)}
      />

      <main className="flex-1 overflow-x-hidden">{renderScreenContent()}</main>

      {/* Android Bottom Navigation (Visible when not inside full tool form or output editor) */}
      {!selectedTool && !activeOutputItem && (
        <BottomNav
          activeTab={activeTab}
          onChangeTab={tab => {
            setActiveTab(tab);
            setSelectedTool(null);
            setActiveOutputItem(null);
          }}
          favoritesCount={favorites.length}
        />
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-200 dark:bg-slate-950 flex items-center justify-center font-sans antialiased">
      {/* Toast notifications */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />

      {/* Device frame container or responsive container */}
      {isDeviceFrameActive ? (
        <div className="w-full max-w-sm h-[840px] my-4 rounded-[44px] bg-slate-900 p-3 shadow-2xl ring-8 ring-slate-800/80 relative flex flex-col overflow-hidden border border-slate-700">
          {/* Android Camera Notch & Speaker */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2">
            <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-700" />
            <div className="w-12 h-1 rounded-full bg-slate-800" />
          </div>

          {/* Android Screen Display */}
          <div className="w-full h-full rounded-[34px] overflow-y-auto overflow-x-hidden bg-slate-50 dark:bg-slate-950 relative flex flex-col pt-3 pb-2 scrollbar-none">
            {appView}
          </div>

          {/* Android Navigation Home Bar */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-28 h-1 rounded-full bg-slate-600 pointer-events-none" />
        </div>
      ) : (
        <div className="w-full min-h-screen">{appView}</div>
      )}

      {/* Global Modals */}
      <PremiumPaywallModal
        isOpen={showPaywall}
        onClose={() => setShowPaywall(false)}
        trialStatus={trialStatus}
        daysRemaining={daysRemaining}
        onContinueFree={() => {
          TrialManager.continueWithFreePlan();
          refreshAppState();
          showToast('Free plan active (3 generations/day).', 'info');
        }}
        onShowPrivacy={() => setShowPrivacy(true)}
        onShowTerms={() => setShowTerms(true)}
        onShowToast={showToast}
      />

      <LimitReachedModal
        isOpen={showLimitModal}
        onClose={() => setShowLimitModal(false)}
        trialStatus={trialStatus}
        onWatchRewardedAd={() => setShowRewardedAd(true)}
        onUpgradePremium={() => setShowPaywall(true)}
      />

      <RewardedAdModal
        isOpen={showRewardedAd}
        onClose={() => setShowRewardedAd(false)}
        onRewardEarned={handleRewardedAdBonusEarned}
      />

      <InterstitialAdModal
        isOpen={showInterstitialAd}
        onClose={() => setShowInterstitialAd(false)}
      />

      <PublishingChecklistModal
        isOpen={showChecklist}
        onClose={() => setShowChecklist(false)}
      />

      <PrivacyPolicyModal
        isOpen={showPrivacy}
        onClose={() => setShowPrivacy(false)}
      />

      <TermsOfServiceModal
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
      />

      <ContactSupportModal
        isOpen={showSupport}
        onClose={() => setShowSupport(false)}
      />
    </div>
  );
}
