import React, { useState } from 'react';
import {
  Sparkles,
  Zap,
  Layers,
  Gift,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'Write smarter with AI',
      subtitle:
        'Transform rough thoughts into polished executive emails, viral social media posts, and persuasive product descriptions in seconds.',
      icon: Sparkles,
      iconColor: 'from-blue-600 via-indigo-600 to-sky-500',
      tag: 'Next-Gen Intelligence',
      badge: '9 Specialized AI Tools',
    },
    {
      title: 'Create professional content faster',
      subtitle:
        'Built for business owners, executives, creators, and job seekers. Choose your tone, length, and language for publication-ready copy.',
      icon: Zap,
      iconColor: 'from-indigo-600 via-purple-600 to-pink-500',
      tag: '10x Speed & Precision',
      badge: 'Custom Tone & Multi-language',
    },
    {
      title: 'Save time with powerful writing tools',
      subtitle:
        'From ATS-tailored CVs and cover letters to full SEO blog articles and grammar checking, all your writing needs under one roof.',
      icon: Layers,
      iconColor: 'from-sky-500 via-blue-600 to-indigo-700',
      tag: 'All-In-One Toolkit',
      badge: 'Local History & Favorites',
    },
    {
      title: 'Start your 30-day free access',
      subtitle:
        'Enjoy 30 days of free access to start writing immediately. No credit card required, no forced account registration.',
      icon: Gift,
      iconColor: 'from-emerald-500 via-teal-600 to-blue-600',
      tag: 'Zero Risk • 100% Free',
      badge: '30 Days Free Included',
    },
  ];

  const step = steps[currentStep];
  const StepIcon = step.icon;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-slate-900 text-white p-6 sm:p-8 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center font-black text-sm">
            W
          </div>
          <span className="font-extrabold tracking-tight text-sm">
            Write<span className="text-blue-400">AI</span>
          </span>
        </div>

        {currentStep < steps.length - 1 && (
          <button
            onClick={onComplete}
            className="text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800 transition-colors"
          >
            Skip
          </button>
        )}
      </div>

      {/* Main Content Carousel */}
      <div className="my-auto py-8 flex flex-col items-center text-center max-w-md mx-auto w-full">
        {/* Animated Icon graphic */}
        <div className="relative mb-8">
          <div
            className={`w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr ${step.iconColor} flex items-center justify-center shadow-2xl shadow-blue-500/20 transform transition-transform duration-500 hover:scale-105`}
          >
            <StepIcon className="w-14 h-14 sm:w-16 sm:h-16 text-white stroke-[1.8]" />
          </div>

          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap px-3 py-0.5 rounded-full bg-slate-800/90 border border-slate-700 text-[10px] font-bold text-blue-300 shadow">
            {step.badge}
          </div>
        </div>

        {/* Tag pill */}
        <span className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-2">
          {step.tag}
        </span>

        {/* Step Title */}
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight mb-3">
          {step.title}
        </h1>

        {/* Step Subtitle */}
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-sm mb-6">
          {step.subtitle}
        </p>

        {/* Step Indicator Dots */}
        <div className="flex items-center gap-2 mb-2">
          {steps.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-2 rounded-full transition-all ${
                idx === currentStep ? 'w-8 bg-blue-500' : 'w-2 bg-slate-700'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="max-w-md mx-auto w-full space-y-3">
        <button
          onClick={handleNext}
          className="w-full py-4 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-extrabold text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all"
        >
          {currentStep === steps.length - 1 ? (
            <>
              <CheckCircle2 className="w-5 h-5 text-emerald-300" />
              <span>Get Started • 30 Days Free</span>
            </>
          ) : (
            <>
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        <p className="text-[10px] text-center text-slate-500">
          Global Android Edition • Google Play & AdMob Ready
        </p>
      </div>
    </div>
  );
};
