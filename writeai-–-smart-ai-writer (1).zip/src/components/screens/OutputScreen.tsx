import React, { useState } from 'react';
import { HistoryItem } from '../../types';
import { HistoryManager } from '../../services/HistoryManager';
import { BannerAd } from '../modals/BannerAd';
import {
  ArrowLeft,
  Copy,
  Share2,
  Bookmark,
  Star,
  RotateCw,
  Trash2,
  Check,
  Edit3,
  Clock,
  Sparkles,
} from 'lucide-react';

interface OutputScreenProps {
  item: HistoryItem;
  isPremium: boolean;
  onBack: () => void;
  onRegenerate: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const OutputScreen: React.FC<OutputScreenProps> = ({
  item,
  isPremium,
  onBack,
  onRegenerate,
  onShowToast,
}) => {
  const [content, setContent] = useState(item.content);
  const [isFavorite, setIsFavorite] = useState(item.isFavorite);
  const [isCopied, setIsCopied] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  // Stats
  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;
  const charCount = content.length;
  const readTimeMin = Math.max(1, Math.ceil(wordCount / 200));

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setIsDirty(true);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setIsCopied(true);
      onShowToast('Copied to clipboard!', 'success');
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      onShowToast('Failed to copy to clipboard.', 'error');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: content,
        });
        onShowToast('Shared successfully!', 'success');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  const handleSaveEdits = () => {
    HistoryManager.updateItem(item.id, content);
    setIsDirty(false);
    onShowToast('Edits saved to history!', 'success');
  };

  const handleToggleFavorite = () => {
    const newState = HistoryManager.toggleFavorite(item.id);
    setIsFavorite(newState);
    onShowToast(
      newState ? 'Added to Favorites!' : 'Removed from Favorites.',
      'info'
    );
  };

  const handleClear = () => {
    if (window.confirm('Clear all content from the editor?')) {
      setContent('');
      setIsDirty(true);
      onShowToast('Content cleared.', 'info');
    }
  };

  return (
    <div className="min-h-full pb-28 text-slate-900 dark:text-white">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="max-w-[200px] sm:max-w-xs">
            <h2 className="text-sm font-bold truncate leading-tight">
              {item.title}
            </h2>
            <p className="text-[10px] text-slate-500 truncate">
              {item.toolName} • {item.optionsSummary || 'Custom options'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Favorite */}
          <button
            onClick={handleToggleFavorite}
            className={`p-2 rounded-xl transition-colors ${
              isFavorite
                ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/60'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
            }`}
            title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          >
            <Star className={`w-5 h-5 ${isFavorite ? 'fill-amber-500' : ''}`} />
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Share content"
          >
            <Share2 className="w-5 h-5" />
          </button>

          {/* Copy */}
          <button
            onClick={handleCopy}
            className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 hover:bg-blue-100 transition-colors"
            title="Copy content"
          >
            {isCopied ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="p-4 max-w-2xl mx-auto space-y-4">
        {/* Quick Toolbar & Stats */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span className="font-semibold">{wordCount} words</span>
            <span>•</span>
            <span>{charCount} characters</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> {readTimeMin} min read
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {isDirty && (
              <button
                onClick={handleSaveEdits}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center gap-1 shadow-sm hover:bg-emerald-500"
              >
                <Bookmark className="w-3 h-3" /> Save Changes
              </button>
            )}

            <button
              onClick={handleClear}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
              title="Clear editor text"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Editable Output Textarea */}
        <div className="relative rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/90 shadow-sm overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
          <div className="flex items-center justify-between px-4 py-2 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-500">
            <span className="flex items-center gap-1.5">
              <Edit3 className="w-3.5 h-3.5 text-blue-500" /> Editable AI Output
            </span>
            <span>Tap anywhere to edit directly</span>
          </div>

          <textarea
            value={content}
            onChange={handleContentChange}
            rows={14}
            className="w-full p-4 bg-transparent text-sm leading-relaxed text-slate-900 dark:text-slate-100 resize-y focus:outline-none font-sans"
            placeholder="AI generation output will appear here..."
          />
        </div>

        {/* Action Button Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
          <button
            onClick={handleCopy}
            className="py-3 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 transition-colors"
          >
            {isCopied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{isCopied ? 'Copied' : 'Copy Text'}</span>
          </button>

          <button
            onClick={handleShare}
            className="py-3 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>

          <button
            onClick={handleToggleFavorite}
            className={`py-3 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors ${
              isFavorite
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200'
            }`}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-500' : ''}`} />
            <span>{isFavorite ? 'Favorited' : 'Favorite'}</span>
          </button>

          <button
            onClick={onRegenerate}
            className="py-3 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <RotateCw className="w-4 h-4" />
            <span>Regenerate</span>
          </button>
        </div>

        {/* Banner Ad Display (Only for non-premium) */}
        <BannerAd isPremium={isPremium} />
      </div>
    </div>
  );
};
