import React, { useState } from 'react';
import { HistoryItem } from '../../types';
import { HistoryManager } from '../../services/HistoryManager';
import { AI_TOOLS } from '../../config/tools.config';
import { ToolIcon } from '../common/ToolIcon';
import {
  Search,
  Copy,
  Share2,
  Trash2,
  Star,
  Clock,
  Sparkles,
  Check,
} from 'lucide-react';

interface HistoryScreenProps {
  onOpenItem: (item: HistoryItem) => void;
  onRefresh: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  onOpenItem,
  onRefresh,
  onShowToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedToolFilter, setSelectedToolFilter] = useState('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const items = HistoryManager.search(searchQuery, selectedToolFilter);

  const handleCopy = async (item: HistoryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(item.content);
      setCopiedId(item.id);
      onShowToast('Copied to clipboard!', 'success');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      onShowToast('Could not copy text.', 'error');
    }
  };

  const handleShare = async (item: HistoryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: item.content,
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy(item, e);
        }
      }
    } else {
      handleCopy(item, e);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    HistoryManager.deleteItem(id);
    onRefresh();
    onShowToast('Deleted from history.', 'info');
  };

  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const state = HistoryManager.toggleFavorite(id);
    onRefresh();
    onShowToast(state ? 'Added to favorites.' : 'Removed from favorites.', 'info');
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to delete all generation history?')) {
      HistoryManager.clearAll();
      onRefresh();
      onShowToast('History cleared completely.', 'info');
    }
  };

  return (
    <div className="min-h-full pb-24 text-slate-900 dark:text-white">
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3">
        <div className="flex items-center justify-between mb-3 max-w-4xl mx-auto">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h1 className="text-base font-extrabold tracking-tight">Writing History</h1>
            <span className="text-xs text-slate-400">({items.length})</span>
          </div>

          {items.length > 0 && (
            <button
              onClick={handleClearAll}
              className="text-xs text-rose-600 dark:text-rose-400 hover:underline font-semibold"
            >
              Clear All
            </button>
          )}
        </div>

        {/* Search & Tool Filter Bar */}
        <div className="space-y-2 max-w-4xl mx-auto">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search history by title, text, or tool..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              onClick={() => setSelectedToolFilter('all')}
              className={`px-3 py-1 rounded-lg font-bold whitespace-nowrap transition-colors ${
                selectedToolFilter === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              All Tools
            </button>
            {AI_TOOLS.map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedToolFilter(t.id)}
                className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedToolFilter === t.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {t.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* List items */}
      <div className="p-4 max-w-4xl mx-auto space-y-3">
        {items.length === 0 ? (
          <div className="text-center py-16 space-y-2">
            <Sparkles className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No History Found
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Generated emails, articles, and descriptions will be preserved here for offline reference.
            </p>
          </div>
        ) : (
          items.map(item => {
            const tool = AI_TOOLS.find(t => t.id === item.toolId);
            return (
              <div
                key={item.id}
                onClick={() => onOpenItem(item)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 hover:border-blue-500 dark:hover:border-blue-500 cursor-pointer shadow-sm hover:shadow transition-all space-y-2 group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center flex-shrink-0">
                      <ToolIcon name={tool?.iconName || 'Sparkles'} className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {item.toolName} • {new Date(item.createdAt).toLocaleDateString()} at{' '}
                        {new Date(item.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={e => handleToggleFavorite(item.id, e)}
                      className={`p-1.5 rounded-lg transition-colors ${
                        item.isFavorite
                          ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/60'
                          : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
                      }`}
                      title="Toggle favorite"
                    >
                      <Star className={`w-4 h-4 ${item.isFavorite ? 'fill-amber-500' : ''}`} />
                    </button>

                    <button
                      onClick={e => handleCopy(item, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                      title="Copy text"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      onClick={e => handleShare(item, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      title="Share"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={e => handleDelete(item.id, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl">
                  {item.content}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>
                    {item.wordCount} words • {item.tone} • {item.language}
                  </span>
                  <span className="text-blue-600 dark:text-blue-400 font-semibold group-hover:underline">
                    Open in Editor →
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
