import React, { useState } from 'react';
import { HistoryItem } from '../../types';
import { HistoryManager } from '../../services/HistoryManager';
import { AI_TOOLS } from '../../config/tools.config';
import { ToolIcon } from '../common/ToolIcon';
import {
  Star,
  Search,
  Copy,
  Share2,
  Trash2,
  Check,
} from 'lucide-react';

interface FavoritesScreenProps {
  onOpenItem: (item: HistoryItem) => void;
  onRefresh: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const FavoritesScreen: React.FC<FavoritesScreenProps> = ({
  onOpenItem,
  onRefresh,
  onShowToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const allFavorites = HistoryManager.getFavorites();
  const filtered = allFavorites.filter(item => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.content.toLowerCase().includes(q) ||
      item.toolName.toLowerCase().includes(q)
    );
  });

  const handleCopy = async (item: HistoryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(item.content);
      setCopiedId(item.id);
      onShowToast('Copied to clipboard!', 'success');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      onShowToast('Could not copy text.', 'error');
    }
  };

  const handleShare = async (item: HistoryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: item.content,
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy(item, e);
        }
      }
    } else {
      handleCopy(item, e);
    }
  };

  const handleRemoveFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    HistoryManager.toggleFavorite(id);
    onRefresh();
    onShowToast('Removed from favorites.', 'info');
  };

  return (
    <div className="min-h-full pb-24 text-slate-900 dark:text-white">
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3">
        <div className="flex items-center justify-between mb-3 max-w-4xl mx-auto">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <h1 className="text-base font-extrabold tracking-tight">Favorite Writings</h1>
            <span className="text-xs text-slate-400">({filtered.length})</span>
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search favorites..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="p-4 max-w-4xl mx-auto space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-16 space-y-2">
            <Star className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No Favorites Saved Yet
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Tap the star icon on any generated content to bookmark your best writings here.
            </p>
          </div>
        ) : (
          filtered.map(item => {
            const tool = AI_TOOLS.find(t => t.id === item.toolId);
            return (
              <div
                key={item.id}
                onClick={() => onOpenItem(item)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-amber-200 dark:border-amber-900/40 hover:border-amber-400 cursor-pointer shadow-sm hover:shadow transition-all space-y-2 group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center flex-shrink-0">
                      <ToolIcon name={tool?.iconName || 'Star'} className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {item.toolName} • {new Date(item.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={e => handleCopy(item, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                      title="Copy"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      onClick={e => handleShare(item, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
                      title="Share"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={e => handleRemoveFavorite(item.id, e)}
                      className="p-1.5 rounded-lg text-amber-500 hover:text-rose-600"
                      title="Remove Favorite"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl">
                  {item.content}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>
                    {item.wordCount} words • {item.tone}
                  </span>
                  <span className="text-amber-600 dark:text-amber-400 font-semibold group-hover:underline">
                    Open Full Text →
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
