import React, { useState } from 'react';
import { AI_TOOLS, ToolConfig } from '../../config/tools.config';
import { HistoryItem, TrialStatus } from '../../types';
import { ToolIcon } from '../common/ToolIcon';
import { TrialManager } from '../../services/TrialManager';
import { BannerAd } from '../modals/BannerAd';
import {
  Sparkles,
  Crown,
  Zap,
  ArrowRight,
  Clock,
  Star,
  Gift,
  ChevronRight,
  Lock,
} from 'lucide-react';

interface HomeScreenProps {
  trialStatus: TrialStatus;
  daysRemaining: number;
  generationsRemaining: number;
  recentHistory: HistoryItem[];
  favorites: HistoryItem[];
  onSelectTool: (tool: ToolConfig) => void;
  onOpenHistoryItem: (item: HistoryItem) => void;
  onOpenPaywall: () => void;
  onOpenUsageModal: () => void;
  onWatchRewardedAd: () => void;
  onNavigateTab: (tab: 'history' | 'favorites') => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  trialStatus,
  daysRemaining,
  generationsRemaining,
  recentHistory,
  favorites,
  onSelectTool,
  onOpenHistoryItem,
  onOpenPaywall,
  onOpenUsageModal,
  onWatchRewardedAd,
  onNavigateTab,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Communication', 'Marketing', 'Career', 'Editing'];

  const filteredTools = AI_TOOLS.filter(
    t => selectedCategory === 'All' || t.category === selectedCategory
  );

  const isPremium = trialStatus === 'PREMIUM_ACTIVE';
  const isTrialActive = trialStatus === 'TRIAL_ACTIVE';
  const isTrialEnded =
    trialStatus === 'TRIAL_EXPIRED' || trialStatus === 'FREE_LIMITED';
  const urgencyReminder = TrialManager.getUrgencyReminder();

  const handleToolClick = (tool: ToolConfig) => {
    // If trial is ended and tool is premium-only, show paywall
    if (isTrialEnded && tool.isPremiumOnlyPostTrial) {
      onOpenPaywall();
      return;
    }
    onSelectTool(tool);
  };

  return (
    <div className="min-h-full pb-24 text-slate-900 dark:text-white">
      <div className="p-4 max-w-5xl mx-auto space-y-6">
        {/* Hero Tagline & Status Card */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-700 via-indigo-700 to-sky-600 text-white p-5 sm:p-7 shadow-xl shadow-blue-500/20">
          <div className="absolute -right-12 -top-12 w-44 h-44 rounded-full bg-white/10 blur-2xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            <div className="space-y-1">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold text-blue-100 uppercase tracking-wider">
                <Sparkles className="w-3 h-3 text-amber-300" />
                Write smarter. Work faster.
              </span>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white leading-tight">
                AI Writing Suite for Professionals
              </h1>
              <p className="text-xs sm:text-sm text-blue-100 max-w-md">
                Create emails, social posts, product listings, resume bullet points, and articles in seconds.
              </p>
            </div>

            {/* Trial & Entitlement Badge */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/20 flex flex-col justify-between min-w-[200px]">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-blue-200">
                  Access Status
                </span>
                {isPremium ? (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-amber-300">
                    <Crown className="w-3.5 h-3.5" /> Premium Active
                  </span>
                ) : isTrialActive ? (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-300">
                    <Gift className="w-3.5 h-3.5" /> 30-Day Free Trial
                  </span>
                ) : trialStatus === 'TRIAL_EXPIRED' ? (
                  <span className="text-[11px] font-bold text-rose-300">
                    Trial Expired
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-slate-200">
                    Free Limited
                  </span>
                )}
              </div>

              {isTrialActive ? (
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-white">
                    Your free access ends in {daysRemaining} days
                  </p>
                  <p className="text-[10px] text-blue-200">
                    20 generations/day free during trial
                  </p>
                  <div className="w-full bg-white/20 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full"
                      style={{ width: `${Math.min(100, (daysRemaining / 30) * 100)}%` }}
                    />
                  </div>
                </div>
              ) : isPremium ? (
                <div className="space-y-0.5">
                  <p className="text-xs font-semibold text-white">
                    Premium Active
                  </p>
                  <p className="text-[11px] text-blue-100">
                    Ad-free • 150 daily generations
                  </p>
                </div>
              ) : (
                <div className="space-y-0.5">
                  <p className="text-xs font-semibold text-white">
                    Free Limited Plan
                  </p>
                  <p className="text-[11px] text-rose-200">
                    3 generations/day • Watch ads for +1 or unlock Premium
                  </p>
                </div>
              )}

              <button
                onClick={onOpenPaywall}
                className="mt-3 w-full py-1.5 px-3 rounded-xl bg-white text-blue-700 hover:bg-blue-50 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                {isPremium ? 'Subscription Details' : 'Unlock Premium'}
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Friendly urgency countdown banner */}
          {urgencyReminder && (
            <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between text-xs text-blue-100">
              <span className="font-medium flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                {urgencyReminder}
              </span>
              <button
                onClick={onOpenPaywall}
                className="text-amber-300 font-bold hover:underline"
              >
                Lock in Premium →
              </button>
            </div>
          )}
        </div>

        {/* Daily Generation Counter & Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div
            onClick={onOpenUsageModal}
            className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between cursor-pointer hover:border-blue-400 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <Zap className="w-5 h-5 fill-amber-500" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-400 uppercase">
                  AI Usage
                </p>
                <p className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  AI generations remaining: {generationsRemaining}
                </p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  {isPremium
                    ? '150 daily limit (Ad-free)'
                    : isTrialActive
                    ? '20 daily limit (30-Day Trial)'
                    : '3 daily limit (Free Plan)'}
                </p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </div>

          {!isPremium && (
            <button
              onClick={onWatchRewardedAd}
              className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 dark:from-amber-950/40 dark:to-orange-950/40 border border-amber-200 dark:border-amber-900/60 shadow-sm flex items-center justify-between text-left hover:border-amber-400 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-amber-800 dark:text-amber-300">
                    Watch Ad for +1 Generation
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Instant bonus for free users
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </button>
          )}

          <div
            onClick={onOpenPaywall}
            className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between cursor-pointer hover:border-blue-400 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-400 uppercase">
                  Plan Tier
                </p>
                <p className="text-sm font-extrabold text-slate-900 dark:text-white">
                  {isPremium
                    ? 'WriteAI Premium'
                    : isTrialActive
                    ? '30-Day Free Trial'
                    : 'Free Limited'}
                </p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        {/* Tools Section Header & Filter Pills */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold tracking-tight">
              AI Writing Tools ({AI_TOOLS.length})
            </h2>
            <span className="text-xs text-slate-500">
              Select a specialized writer
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Tools Grid (9 working AI tools) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredTools.map(tool => {
            const isLocked = isTrialEnded && tool.isPremiumOnlyPostTrial;

            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => handleToolClick(tool)}
                className="group relative p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 hover:border-blue-500 dark:hover:border-blue-500 text-left shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                {isLocked && (
                  <span className="absolute top-3 right-3 px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] font-bold flex items-center gap-1 border border-amber-500/20">
                    <Lock className="w-2.5 h-2.5" /> PRO
                  </span>
                )}

                <div>
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <ToolIcon name={tool.iconName} className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                    {tool.tagline}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-medium text-slate-500">{tool.category}</span>
                  <span className="text-blue-600 dark:text-blue-400 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    {isLocked ? 'Unlock' : 'Open'} <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Recent History & Favorites Preview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Recent History Preview */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h3 className="text-sm font-bold">Recent History</h3>
              </div>
              <button
                onClick={() => onNavigateTab('history')}
                className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                View all ({recentHistory.length})
              </button>
            </div>

            {recentHistory.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">
                No recent writing generated yet. Choose a tool above to begin!
              </p>
            ) : (
              <div className="space-y-2">
                {recentHistory.slice(0, 3).map(item => (
                  <div
                    key={item.id}
                    onClick={() => onOpenHistoryItem(item)}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 hover:bg-blue-50 dark:hover:bg-blue-950/40 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="truncate max-w-[200px]">{item.title}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {item.content}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Favorites Preview */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <h3 className="text-sm font-bold">Starred Favorites</h3>
              </div>
              <button
                onClick={() => onNavigateTab('favorites')}
                className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                View all ({favorites.length})
              </button>
            </div>

            {favorites.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">
                Star your favorite generated outputs to quickly reference them anytime.
              </p>
            ) : (
              <div className="space-y-2">
                {favorites.slice(0, 3).map(item => (
                  <div
                    key={item.id}
                    onClick={() => onOpenHistoryItem(item)}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 hover:bg-amber-50 dark:hover:bg-amber-950/30 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="truncate max-w-[200px]">{item.title}</span>
                      <span className="text-[10px] text-amber-600 dark:text-amber-400">
                        {item.toolName}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {item.content}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* AdMob Banner for Free/Trial Users */}
        <BannerAd isPremium={isPremium} />
      </div>
    </div>
  );
};
