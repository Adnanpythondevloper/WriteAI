import React, { useState } from 'react';
import { Tone, ContentLength, TargetLanguage, UserSettings, TrialStatus } from '../../types';
import { StorageManager } from '../../services/StorageManager';
import { TrialManager } from '../../services/TrialManager';
import { BillingManager } from '../../services/BillingManager';
import { UsageManager } from '../../services/UsageManager';
import { ACTIVE_AD_IDS, USE_PRODUCTION_ADMOB } from '../../config/admob.config';
import {
  Settings as SettingsIcon,
  Crown,
  Moon,
  Sun,
  ShieldCheck,
  FileText,
  Mail,
  Trash2,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  Info,
  Bug,
  Smartphone,
  Sliders,
} from 'lucide-react';

interface SettingsScreenProps {
  settings: UserSettings;
  trialStatus: TrialStatus;
  daysRemaining: number;
  onUpdateSettings: (newSettings: UserSettings) => void;
  onOpenPaywall: () => void;
  onShowPrivacy: () => void;
  onShowTerms: () => void;
  onShowSupport: () => void;
  onShowChecklist: () => void;
  onRefreshAppState: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

const TONES: Tone[] = [
  'Professional',
  'Friendly',
  'Formal',
  'Casual',
  'Persuasive',
  'Creative',
  'Simple',
];

const LENGTHS: ContentLength[] = ['Short', 'Medium', 'Long'];

const LANGUAGES: TargetLanguage[] = [
  'English',
  'Spanish',
  'French',
  'German',
  'Italian',
  'Portuguese',
  'Arabic',
  'Urdu',
  'Hindi',
];

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  trialStatus,
  daysRemaining,
  onUpdateSettings,
  onOpenPaywall,
  onShowPrivacy,
  onShowTerms,
  onShowSupport,
  onShowChecklist,
  onRefreshAppState,
  onShowToast,
}) => {
  const [showDeveloperInspector, setShowDeveloperInspector] = useState(false);
  const isPremium = trialStatus === 'PREMIUM_ACTIVE';

  const handleUpdate = (partial: Partial<UserSettings>) => {
    const updated = { ...settings, ...partial };
    StorageManager.saveSettings(updated);
    onUpdateSettings(updated);
    onShowToast('Settings saved.', 'info');
  };

  const handleClearHistory = () => {
    if (window.confirm('Delete all stored generation history?')) {
      StorageManager.clearHistory();
      onRefreshAppState();
      onShowToast('History deleted.', 'info');
    }
  };

  const handleClearFavorites = () => {
    if (window.confirm('Remove all starred favorites?')) {
      StorageManager.clearFavorites();
      onRefreshAppState();
      onShowToast('Favorites cleared.', 'info');
    }
  };

  const handleRestore = async () => {
    const res = await BillingManager.restorePurchases();
    if (res.restored) {
      onShowToast(res.message, 'success');
      onRefreshAppState();
    } else {
      onShowToast(res.message, 'info');
    }
  };

  return (
    <div className="min-h-full pb-28 text-slate-900 dark:text-white">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3">
        <div className="flex items-center gap-2 max-w-2xl mx-auto">
          <SettingsIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          <h1 className="text-base font-extrabold tracking-tight">App Settings</h1>
        </div>
      </div>

      <div className="p-4 max-w-2xl mx-auto space-y-6">
        {/* Subscription & Entitlement Banner */}
        <div className="p-4 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-md border border-blue-800/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold">
                  {isPremium
                    ? 'WriteAI Premium Subscription'
                    : trialStatus === 'TRIAL_ACTIVE'
                    ? '30-Day Free Trial Active'
                    : 'Free Limited Access'}
                </h3>
                <p className="text-xs text-blue-200">
                  {isPremium
                    ? 'Unlimited tools • Ad-free experience • Priority'
                    : trialStatus === 'TRIAL_ACTIVE'
                    ? `${daysRemaining} days remaining in trial`
                    : 'Limited to 3 daily generations'}
                </p>
              </div>
            </div>

            <button
              onClick={onOpenPaywall}
              className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow"
            >
              {isPremium ? 'Plan Info' : 'Upgrade'}
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
            <button
              onClick={handleRestore}
              className="text-blue-300 hover:text-white flex items-center gap-1 font-medium"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Restore Google Play Purchases</span>
            </button>
            <span className="text-slate-400 font-mono text-[11px]">
              ID: com.writeai.smartwriter
            </span>
          </div>
        </div>

        {/* AI Defaults Customization */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-500" /> Default Writing Preferences
          </h3>

          {/* Default Tone */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Default Tone
            </label>
            <select
              value={settings.defaultTone}
              onChange={e => handleUpdate({ defaultTone: e.target.value as Tone })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium"
            >
              {TONES.map(t => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Default Length */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Default Content Length
            </label>
            <div className="grid grid-cols-3 gap-2">
              {LENGTHS.map(len => (
                <button
                  key={len}
                  onClick={() => handleUpdate({ defaultLength: len })}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    settings.defaultLength === len
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {len}
                </button>
              ))}
            </div>
          </div>

          {/* Default Language */}
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Default AI Output Language
            </label>
            <select
              value={settings.defaultLanguage}
              onChange={e =>
                handleUpdate({ defaultLanguage: e.target.value as TargetLanguage })
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-medium"
            >
              {LANGUAGES.map(l => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-400">
              Note: The app UI remains English while AI generates content in your preferred language.
            </p>
          </div>
        </div>

        {/* Appearance & Dark Mode */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Appearance
          </h3>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleUpdate({ darkMode: 'light' })}
              className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                settings.darkMode === 'light'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950 text-blue-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              <Sun className="w-5 h-5" />
              <span>Light Mode</span>
            </button>

            <button
              onClick={() => handleUpdate({ darkMode: 'dark' })}
              className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                settings.darkMode === 'dark'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950 text-blue-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              <Moon className="w-5 h-5" />
              <span>Dark Mode</span>
            </button>

            <button
              onClick={() => handleUpdate({ darkMode: 'system' })}
              className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                settings.darkMode === 'system'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950 text-blue-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              <Smartphone className="w-5 h-5" />
              <span>System</span>
            </button>
          </div>
        </div>

        {/* Data & Storage Management */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Storage & History
          </h3>

          <div className="flex gap-3">
            <button
              onClick={handleClearHistory}
              className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 hover:border-rose-400 hover:text-rose-600 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Trash2 className="w-4 h-4 text-slate-400" />
              <span>Clear History</span>
            </button>

            <button
              onClick={handleClearFavorites}
              className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 hover:border-rose-400 hover:text-rose-600 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Trash2 className="w-4 h-4 text-slate-400" />
              <span>Clear Favorites</span>
            </button>
          </div>
        </div>

        {/* Legal, Support & About */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm divide-y divide-slate-100 dark:divide-slate-800">
          <button
            onClick={onShowChecklist}
            className="w-full py-3 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Before Google Play Publishing Checklist</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onShowPrivacy}
            className="w-full py-3 flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-blue-600"
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-slate-400" />
              <span>Privacy Policy</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <button
            onClick={onShowTerms}
            className="w-full py-3 flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-blue-600"
          >
            <div className="flex items-center gap-2.5">
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Terms of Service</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <button
            onClick={onShowSupport}
            className="w-full py-3 flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-blue-600"
          >
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>Contact Support</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>

        {/* Developer / QA Sandbox Inspector Toggle */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-400">
              <Bug className="w-4 h-4 text-indigo-500" />
              <span>QA & Sandbox Inspector</span>
            </div>
            <button
              onClick={() => setShowDeveloperInspector(!showDeveloperInspector)}
              className="text-xs text-blue-600 font-bold hover:underline"
            >
              {showDeveloperInspector ? 'Hide' : 'Open Tools'}
            </button>
          </div>

          {showDeveloperInspector && (
            <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs animate-in fade-in">
              <p className="text-[11px] text-slate-500">
                Use these tools to test all 30-day trial countdowns, daily usage limits, and AdMob events.
              </p>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={async () => {
                    await TrialManager.simulateDaysRemaining(7);
                    onRefreshAppState();
                    onShowToast('Simulated: 7 days remaining.', 'info');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold"
                >
                  Set 7 Days Left
                </button>

                <button
                  onClick={async () => {
                    await TrialManager.simulateDaysRemaining(1);
                    onRefreshAppState();
                    onShowToast('Simulated: 1 day remaining.', 'info');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold"
                >
                  Set 1 Day Left
                </button>

                <button
                  onClick={async () => {
                    await TrialManager.simulateDaysRemaining(0);
                    onRefreshAppState();
                    onShowToast('Simulated: Trial Expired (Free Plan 3/day).', 'info');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-rose-600"
                >
                  Expire Trial (0 days)
                </button>

                <button
                  onClick={async () => {
                    await TrialManager.resetTrialToFull30Days();
                    onRefreshAppState();
                    onShowToast('Trial reset to full 30 days (20/day).', 'success');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-emerald-600"
                >
                  Reset Full 30 Days
                </button>

                <button
                  onClick={() => {
                    UsageManager.exhaustDailyUsageForTesting();
                    onRefreshAppState();
                    onShowToast('Daily limit exhausted.', 'info');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-amber-600"
                >
                  Exhaust Daily Limit
                </button>

                <button
                  onClick={() => {
                    UsageManager.resetDailyUsageForTesting();
                    onRefreshAppState();
                    onShowToast('Daily limit reset.', 'success');
                  }}
                  className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-blue-600"
                >
                  Reset Daily Limit
                </button>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-[10px] font-mono text-slate-500 space-y-0.5">
                <p>AdMob Mode: {USE_PRODUCTION_ADMOB ? 'Production Live' : 'Development Test'}</p>
                <p>AdMob App ID: {ACTIVE_AD_IDS.ADMOB_APP_ID}</p>
                <p>Rewarded Unit: {ACTIVE_AD_IDS.ADMOB_REWARDED_ID}</p>
              </div>
            </div>
          )}
        </div>

        {/* App Info Footer */}
        <div className="text-center pt-2 pb-6 space-y-1 text-slate-400">
          <p className="text-xs font-bold text-slate-600 dark:text-slate-400">
            WriteAI – Smart AI Writer
          </p>
          <p className="text-[11px]">
            Version 1.0.0 (Build 1) • Package: <span className="font-mono">com.writeai.smartwriter</span>
          </p>
          <p className="text-[10px] text-slate-500">
            © 2026 WriteAI Technologies. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};
