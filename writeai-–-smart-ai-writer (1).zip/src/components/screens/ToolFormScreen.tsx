import React, { useState } from 'react';
import { ToolConfig } from '../../config/tools.config';
import { Tone, ContentLength, TargetLanguage, HistoryItem } from '../../types';
import { ToolIcon } from '../common/ToolIcon';
import { AIService } from '../../services/AIService';
import { UsageManager } from '../../services/UsageManager';
import { HistoryManager } from '../../services/HistoryManager';
import {
  ArrowLeft,
  Sparkles,
  Loader2,
  AlertCircle,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';

interface ToolFormScreenProps {
  tool: ToolConfig;
  defaultTone: Tone;
  defaultLength: ContentLength;
  defaultLanguage: TargetLanguage;
  onBack: () => void;
  onGenerationComplete: (item: HistoryItem) => void;
  onLimitReached: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

const TONES: Tone[] = [
  'Professional',
  'Friendly',
  'Formal',
  'Casual',
  'Persuasive',
  'Creative',
  'Simple',
];

const LENGTHS: ContentLength[] = ['Short', 'Medium', 'Long'];

const LANGUAGES: TargetLanguage[] = [
  'English',
  'Spanish',
  'French',
  'German',
  'Italian',
  'Portuguese',
  'Arabic',
  'Urdu',
  'Hindi',
];

export const ToolFormScreen: React.FC<ToolFormScreenProps> = ({
  tool,
  defaultTone,
  defaultLength,
  defaultLanguage,
  onBack,
  onGenerationComplete,
  onLimitReached,
  onShowToast,
}) => {
  // Pre-fill initial fields
  const [formValues, setFormValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    tool.fields.forEach(f => {
      if (f.options && f.options.length > 0) {
        init[f.id] = f.options[0];
      } else {
        init[f.id] = '';
      }
    });
    return init;
  });

  const [selectedTone, setSelectedTone] = useState<Tone>(defaultTone);
  const [selectedLength, setSelectedLength] = useState<ContentLength>(defaultLength);
  const [selectedLanguage, setSelectedLanguage] = useState<TargetLanguage>(defaultLanguage);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleInputChange = (fieldId: string, value: string) => {
    setFormValues(prev => ({ ...prev, [fieldId]: value }));
    if (errorMessage) setErrorMessage(null);
  };

  const handleClear = () => {
    const cleared: Record<string, string> = {};
    tool.fields.forEach(f => {
      if (f.options && f.options.length > 0) {
        cleared[f.id] = f.options[0];
      } else {
        cleared[f.id] = '';
      }
    });
    setFormValues(cleared);
    setErrorMessage(null);
  };

  const handleGenerate = async () => {
    // Check daily limit
    if (!UsageManager.canGenerate()) {
      onLimitReached();
      return;
    }

    // Validate required fields
    const missingField = tool.fields.find(
      f => f.required && (!formValues[f.id] || formValues[f.id].trim().length === 0)
    );

    if (missingField) {
      setErrorMessage(`Please complete the "${missingField.label}" field.`);
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    // Compute title
    const title =
      formValues.subject ||
      formValues.productName ||
      formValues.topic ||
      formValues.targetRole ||
      formValues.jobTitle ||
      `${tool.name} Output`;

    try {
      const response = await AIService.generate({
        toolId: tool.id,
        title,
        inputs: formValues,
        tone: selectedTone,
        length: selectedLength,
        language: selectedLanguage,
      });

      // Save to local history
      const savedItem = HistoryManager.addItem({
        toolId: tool.id,
        toolName: tool.name,
        title,
        content: response.text,
        tone: selectedTone,
        length: selectedLength,
        language: selectedLanguage,
        optionsSummary: `${selectedTone} • ${selectedLength} • ${selectedLanguage}`,
      });

      onShowToast('Content created successfully!', 'success');
      onGenerationComplete(savedItem);
    } catch (error: any) {
      console.error('Generation error', error);
      const msg = error.message || 'Failed to generate content. Please try again.';
      setErrorMessage(msg);
      if (msg.includes('daily generation limit')) {
        onLimitReached();
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full pb-24 text-slate-900 dark:text-white">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            disabled={isLoading}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <ToolIcon name={tool.iconName} className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold leading-tight">{tool.name}</h2>
              <p className="text-[10px] text-slate-500">{tool.category}</p>
            </div>
          </div>
        </div>

        <button
          onClick={handleClear}
          disabled={isLoading}
          className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Reset input fields"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      <div className="p-4 max-w-xl mx-auto space-y-5">
        {/* Tool tagline banner */}
        <div className="p-3.5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50 text-xs text-blue-900 dark:text-blue-200">
          {tool.tagline}
        </div>

        {/* Dynamic Fields */}
        <div className="space-y-4">
          {tool.fields.map(field => {
            const isSelect = field.type === 'select';
            const isTextarea = field.type === 'textarea';

            return (
              <div key={field.id} className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  {field.label}{' '}
                  {field.required && (
                    <span className="text-rose-500 font-bold">*</span>
                  )}
                </label>

                {isSelect ? (
                  <select
                    value={formValues[field.id] || ''}
                    onChange={e => handleInputChange(field.id, e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {field.options?.map(opt => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                ) : isTextarea ? (
                  <textarea
                    rows={field.rows || 3}
                    placeholder={field.placeholder}
                    value={formValues[field.id] || ''}
                    onChange={e => handleInputChange(field.id, e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder:text-slate-400"
                  />
                ) : (
                  <input
                    type="text"
                    placeholder={field.placeholder}
                    value={formValues[field.id] || ''}
                    onChange={e => handleInputChange(field.id, e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder:text-slate-400"
                  />
                )}

                {field.helperText && (
                  <p className="text-[11px] text-amber-600 dark:text-amber-400 leading-tight">
                    {field.helperText}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        {/* AI Options Selector (Tone, Length, Language) */}
        <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setShowAdvancedOptions(prev => !prev)}
            className="w-full flex items-center justify-between py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-blue-600"
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>
                Writing Options: {selectedTone} • {selectedLength} • {selectedLanguage}
              </span>
            </div>
            <span className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold">
              {showAdvancedOptions ? 'Hide' : 'Customize'}
            </span>
          </button>

          {showAdvancedOptions && (
            <div className="mt-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3.5 animate-in fade-in duration-200">
              {/* Tone */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                  Tone of Voice
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {TONES.map(tone => (
                    <button
                      key={tone}
                      type="button"
                      onClick={() => setSelectedTone(tone)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                        selectedTone === tone
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-slate-300'
                      }`}
                    >
                      {tone}
                    </button>
                  ))}
                </div>
              </div>

              {/* Length */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                  Target Length
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {LENGTHS.map(len => (
                    <button
                      key={len}
                      type="button"
                      onClick={() => setSelectedLength(len)}
                      className={`py-1.5 rounded-lg text-xs font-semibold text-center transition-all ${
                        selectedLength === len
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {len}
                    </button>
                  ))}
                </div>
              </div>

              {/* Language */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                  Output Language
                </label>
                <select
                  value={selectedLanguage}
                  onChange={e => setSelectedLanguage(e.target.value as TargetLanguage)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium"
                >
                  {LANGUAGES.map(lang => (
                    <option key={lang} value={lang}>
                      {lang}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <p className="flex-1">{errorMessage}</p>
          </div>
        )}

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 hover:from-blue-700 hover:to-indigo-700 active:from-blue-800 active:to-indigo-800 text-white font-extrabold text-sm shadow-xl shadow-blue-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-60"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Writing your content…</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>Generate with AI</span>
            </>
          )}
        </button>

        {/* In-flight loading card */}
        {isLoading && (
          <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 text-center space-y-3 animate-in fade-in duration-300">
            <div className="flex items-center justify-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-ping" />
              <p className="text-sm font-bold">Writing your content…</p>
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Synthesizing structure, applying {selectedTone} tone, and crafting output in {selectedLanguage}.
            </p>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-blue-500 to-sky-400 h-full w-2/3 animate-[pulse_1.5s_ease-in-out_infinite]" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
