import React from 'react';
import {
  Mail,
  Share2,
  ShoppingBag,
  BookOpen,
  FileText,
  Award,
  Sparkles,
  ListOrdered,
  CheckCheck,
  PenTool,
} from 'lucide-react';

interface ToolIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const ToolIcon: React.FC<ToolIconProps> = ({ name, className = 'w-5 h-5', size }) => {
  switch (name) {
    case 'Mail':
      return <Mail className={className} size={size} />;
    case 'Share2':
      return <Share2 className={className} size={size} />;
    case 'ShoppingBag':
      return <ShoppingBag className={className} size={size} />;
    case 'BookOpen':
      return <BookOpen className={className} size={size} />;
    case 'FileText':
      return <FileText className={className} size={size} />;
    case 'Award':
      return <Award className={className} size={size} />;
    case 'Sparkles':
      return <Sparkles className={className} size={size} />;
    case 'ListOrdered':
      return <ListOrdered className={className} size={size} />;
    case 'CheckCheck':
      return <CheckCheck className={className} size={size} />;
    default:
      return <PenTool className={className} size={size} />;
  }
};
