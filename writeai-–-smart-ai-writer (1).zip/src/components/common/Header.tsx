import React from 'react';
import { Sparkles, Crown, Zap, Smartphone, Monitor } from 'lucide-react';
import { TrialStatus } from '../../types';

interface HeaderProps {
  trialStatus: TrialStatus;
  daysRemaining: number;
  generationsRemaining: number;
  onOpenPaywall: () => void;
  onOpenUsageModal: () => void;
  isDeviceFrameActive: boolean;
  onToggleDeviceFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  trialStatus,
  daysRemaining,
  generationsRemaining,
  onOpenPaywall,
  onOpenUsageModal,
  isDeviceFrameActive,
  onToggleDeviceFrame,
}) => {
  const isPremium = trialStatus === 'PREMIUM_ACTIVE';
  const isTrial = trialStatus === 'TRIAL_ACTIVE';

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 transition-colors">
      <div className="flex items-center justify-between gap-2 max-w-5xl mx-auto">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-slate-900 dark:text-white">
                Write<span className="text-blue-600 dark:text-blue-400">AI</span>
              </span>
              {isPremium && (
                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                  <Crown className="w-2.5 h-2.5" /> PRO
                </span>
              )}
            </div>
            <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 leading-none">
              Smart AI Writer
            </p>
          </div>
        </div>

        {/* Right Badges & Controls */}
        <div className="flex items-center gap-2">
          {/* Trial / Premium Status Pill */}
          <button
            onClick={onOpenPaywall}
            className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm ${
              isPremium
                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-700'
                : isTrial
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100'
                : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
            }`}
            title="View Subscription & Trial status"
          >
            {isPremium ? (
              <>
                <Crown className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>Premium Active</span>
              </>
            ) : isTrial ? (
              <>
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                <span className="hidden sm:inline">30-Day Free Trial</span>
                <span className="sm:hidden">{daysRemaining}d Trial</span>
              </>
            ) : (
              <span>Free Plan</span>
            )}
          </button>

          {/* Daily limit badge */}
          <button
            onClick={onOpenUsageModal}
            className="px-2.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 transition-colors"
            title="Daily AI generation remaining"
          >
            <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>{generationsRemaining} left</span>
          </button>

          {/* Android Frame Toggle */}
          <button
            onClick={onToggleDeviceFrame}
            className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isDeviceFrameActive ? 'Switch to Full Width Mode' : 'Switch to Android Phone Bezel'}
          >
            {isDeviceFrameActive ? (
              <Monitor className="w-4 h-4" />
            ) : (
              <Smartphone className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
