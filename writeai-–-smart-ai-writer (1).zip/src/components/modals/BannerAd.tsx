import React, { useState } from 'react';
import { ACTIVE_AD_IDS } from '../../config/admob.config';
import { ExternalLink, X } from 'lucide-react';

interface BannerAdProps {
  isPremium: boolean;
}

export const BannerAd: React.FC<BannerAdProps> = ({ isPremium }) => {
  const [dismissed, setDismissed] = useState(false);

  // Hide ads completely for Premium users
  if (isPremium || dismissed) {
    return null;
  }

  return (
    <div className="w-full my-3 px-4">
      <div className="relative mx-auto max-w-lg overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 shadow-sm p-2.5">
        <div className="flex items-center justify-between gap-2 mb-1">
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
              Ad • Google AdMob Test
            </span>
            <span className="text-[9px] font-mono text-slate-400 truncate max-w-[170px]">
              ID: {ACTIVE_AD_IDS.ADMOB_BANNER_ID}
            </span>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 rounded"
            title="Collapse Ad"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
              G
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-snug">
                Google Cloud Developer Tools
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Deploy scalable web & Android backends effortlessly.
              </p>
            </div>
          </div>
          <a
            href="https://developers.google.com"
            target="_blank"
            rel="noreferrer"
            className="flex-shrink-0 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 flex items-center gap-1"
          >
            Install <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
