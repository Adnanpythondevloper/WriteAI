import React, { useState, useEffect } from 'react';
import { ACTIVE_AD_IDS } from '../../config/admob.config';
import { Gift, X, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardEarned: () => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  onClose,
  onRewardEarned,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(5);
  const [isCompleted, setIsCompleted] = useState(false);
  const [showEarlyCloseConfirm, setShowEarlyCloseConfirm] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSecondsLeft(5);
      setIsCompleted(false);
      setShowEarlyCloseConfirm(false);
      return;
    }

    const interval = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsCompleted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAttemptClose = () => {
    if (isCompleted) {
      onRewardEarned();
      onClose();
    } else {
      setShowEarlyCloseConfirm(true);
    }
  };

  const handleClaimReward = () => {
    onRewardEarned();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 text-white overflow-hidden shadow-2xl relative">
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950/70 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold text-[10px]">
              AdMob Rewarded Video
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ID: ...{ACTIVE_AD_IDS.ADMOB_REWARDED_ID.slice(-6)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {!isCompleted ? (
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[11px] font-semibold text-slate-300">
                Reward in {secondsLeft}s
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 text-[11px] font-bold border border-emerald-800 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Ready
              </span>
            )}
            <button
              onClick={handleAttemptClose}
              className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Video simulation stage */}
        <div className="relative aspect-[9/12] max-h-[380px] bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 flex flex-col items-center justify-center p-6 text-center">
          {/* Animated sponsor logo */}
          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center shadow-lg shadow-blue-500/30 animate-pulse">
              <Gift className="w-10 h-10 text-white" />
            </div>
            <div className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded bg-amber-500 text-slate-900 font-black text-[10px] tracking-wider uppercase shadow">
              +1 Free
            </div>
          </div>

          <h3 className="text-xl font-bold mb-2">WriteAI Sponsored Partner</h3>
          <p className="text-xs text-slate-400 max-w-xs mb-6">
            Supporting independent AI productivity developers worldwide. Watch full video to claim your bonus generation.
          </p>

          {/* Progress bar */}
          <div className="w-full bg-slate-800 rounded-full h-2 mb-2 overflow-hidden border border-slate-700">
            <div
              className="bg-gradient-to-r from-blue-500 to-emerald-400 h-full transition-all duration-1000 ease-linear rounded-full"
              style={{ width: `${((5 - secondsLeft) / 5) * 100}%` }}
            />
          </div>

          <p className="text-[11px] text-slate-500">
            {isCompleted
              ? 'Verification complete: 1 Bonus AI Generation granted!'
              : `Playing AdMob test creative... (${secondsLeft}s remaining)`}
          </p>

          {/* Action button */}
          {isCompleted && (
            <button
              onClick={handleClaimReward}
              className="mt-6 w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 animate-bounce"
            >
              <CheckCircle2 className="w-5 h-5" /> Claim +1 Free Generation
            </button>
          )}
        </div>

        {/* Early Close Warning Prompt */}
        {showEarlyCloseConfirm && !isCompleted && (
          <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-20 animate-in fade-in">
            <AlertTriangle className="w-12 h-12 text-amber-400 mb-3" />
            <h4 className="text-base font-bold mb-1">Leave without reward?</h4>
            <p className="text-xs text-slate-400 mb-6">
              You must watch the entire ad to receive your +1 bonus AI generation. Only {secondsLeft} seconds remain.
            </p>
            <div className="flex gap-3 w-full">
              <button
                onClick={() => setShowEarlyCloseConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold"
              >
                Resume Video
              </button>
              <button
                onClick={() => {
                  setShowEarlyCloseConfirm(false);
                  onClose();
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Discard Reward
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
