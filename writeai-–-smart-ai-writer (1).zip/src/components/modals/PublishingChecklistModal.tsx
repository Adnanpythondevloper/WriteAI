import React, { useState } from 'react';
import {
  X,
  CheckSquare,
  Square,
  AlertCircle,
  Copy,
  Check,
  ShieldAlert,
  CreditCard,
  DollarSign,
  Code,
  Smartphone,
} from 'lucide-react';
import {
  DEVELOPMENT_AD_UNIT_IDS,
  PRODUCTION_AD_UNIT_IDS,
  USE_PRODUCTION_ADMOB,
} from '../../config/admob.config';

interface PublishingChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PublishingChecklistModal: React.FC<PublishingChecklistModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'checklist' | 'admob' | 'play_console' | 'production_config' | 'payouts'>('checklist');
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyText = (txt: string, key: string) => {
    navigator.clipboard?.writeText(txt);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const checklistItems = [
    {
      id: 'ai_backend',
      category: '1. AI Provider & Backend',
      title: 'Production Gemini API & Server Key',
      description: 'Host backend on Cloud Run / Node with GEMINI_API_KEY environment variable. Do not embed keys in client APK.',
      actionRequired: 'Ensure production server is deployed with real GEMINI_API_KEY injected.',
    },
    {
      id: 'admob_app_id',
      category: '2. Google AdMob Advertising',
      title: 'Register Real AdMob App ID',
      description: 'Create an Android App in AdMob Console and update AndroidManifest.xml: meta-data com.google.android.gms.ads.APPLICATION_ID.',
      actionRequired: 'Replace ca-app-pub-3940256099942544~3347511713 with your live AdMob App ID.',
    },
    {
      id: 'admob_units',
      category: '2. Google AdMob Advertising',
      title: 'Replace AdMob Test Ad Units with Live Units',
      description: 'Create real Banner, Interstitial, and Rewarded units in admob.google.com and update src/config/admob.config.ts.',
      actionRequired: 'Paste production Banner, Interstitial, and Rewarded ad unit IDs.',
    },
    {
      id: 'play_console',
      category: '3. Google Play Store Console',
      title: 'Google Play Developer Account Registration',
      description: 'Pay $25 registration fee on play.google.com/console and create application com.writeai.smartwriter.',
      actionRequired: 'Complete developer identity verification and D-U-N-S number (if organization).',
    },
    {
      id: 'billing_products',
      category: '3. Google Play Store Console',
      title: 'Configure Play Console Subscriptions',
      description: 'Under Monetize -> Subscriptions, create writeai_premium_monthly ($4.99) and writeai_premium_yearly ($39.99).',
      actionRequired: 'Set base plans, activation rules, and auto-renew grace period.',
    },
    {
      id: 'privacy_url',
      category: '4. Legal & Compliance',
      title: 'Public Privacy Policy & Terms URL',
      description: 'Google Play requires a live, publicly accessible HTTPS Privacy Policy URL covering AdMob and AI usage.',
      actionRequired: 'Host the provided Privacy Policy on your domain and submit URL in Play Console App Content.',
    },
    {
      id: 'data_safety',
      category: '4. Legal & Compliance',
      title: 'Data Safety & Content Rating Questionnaires',
      description: 'Declare ad identifiers (AdMob), user-provided text for AI processing, and complete IARC age rating.',
      actionRequired: 'Fill out Play Console Data Safety form declaring Advertising & App Functionality data types.',
    },
    {
      id: 'signed_aab',
      category: '5. Build & Packaging',
      title: 'Generate Production Signed Android App Bundle (.aab)',
      description: 'Create an upload keystore (keytool) and build signed release bundle via Android Studio / Capacitor build.',
      actionRequired: 'Generate release.keystore and execute ./gradlew bundleRelease.',
    },
  ];

  const admobSteps = [
    '1. Sign in to your Google AdMob account at https://admob.google.com',
    '2. Click Apps -> Add App -> Choose Android -> Select "No" (if not published yet) or "Yes"',
    '3. Name the app: WriteAI – Smart AI Writer (com.writeai.smartwriter)',
    '4. Create Banner Ad Unit -> Name it "Main Bottom Banner" -> Copy Unit ID',
    '5. Create Interstitial Ad Unit -> Name it "Natural Transition Interstitial" -> Copy Unit ID',
    '6. Create Rewarded Ad Unit -> Name it "Bonus Generation Rewarded Video" -> Set reward to 1 generation -> Copy Unit ID',
    '7. Copy your AdMob App ID (format: ca-app-pub-XXXXXXXXXXXX~YYYYYYYYYY)',
    '8. Paste IDs into src/config/admob.config.ts in PRODUCTION_AD_UNIT_IDS and keep USE_PRODUCTION_ADMOB=false until ready for final store build!',
  ];

  const playConsoleSteps = [
    '1. Sign in to Google Play Console at https://play.google.com/console',
    '2. Click "Create app" -> App name: "WriteAI – Smart AI Writer" -> Default language: English (United States) -> Free app',
    '3. Under Monetization -> Subscriptions -> Create Subscription:',
    '   - Product ID: writeai_premium_monthly (Base plan: $4.99/month auto-renewing)',
    '   - Product ID: writeai_premium_yearly (Base plan: $39.99/year auto-renewing with 33% discount)',
    '4. Configure Google Payments Merchant Profile in Google Play Console to link your developer bank account for subscription payouts.',
    '5. In App Content, complete Data Safety Questionnaire declaring Advertising (AdMob device identifiers) and AI content processing.',
    '6. Complete Content Rating Questionnaire (suitable for General / Teen).',
    '7. Enter your public Privacy Policy HTTPS URL in App Content -> Privacy Policy.',
    '8. Provide High-res App Icon (512x512 PNG), Feature Graphic (1024x500 JPEG/PNG), and 4 phone screenshots.',
    '9. Build signed Android App Bundle (.aab) with your upload keystore and upload to Internal Testing or Closed Testing track.',
    '10. Test real Google Play Billing purchases using licensed test email accounts before promoting to Production.',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto text-slate-900 dark:text-white flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div>
            <h3 className="text-base sm:text-lg font-black flex items-center gap-2">
              <span>Google Play & AdMob Production Setup</span>
            </h3>
            <p className="text-xs text-slate-500 font-mono">
              Package: com.writeai.smartwriter • Version 1.0.0
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-850 px-3 overflow-x-auto no-scrollbar text-xs">
          <button
            onClick={() => setActiveTab('checklist')}
            className={`py-2.5 px-3 font-bold whitespace-nowrap border-b-2 transition-colors ${
              activeTab === 'checklist'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Launch Checklist
          </button>
          <button
            onClick={() => setActiveTab('admob')}
            className={`py-2.5 px-3 font-bold whitespace-nowrap border-b-2 transition-colors ${
              activeTab === 'admob'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            AdMob Setup Guide
          </button>
          <button
            onClick={() => setActiveTab('play_console')}
            className={`py-2.5 px-3 font-bold whitespace-nowrap border-b-2 transition-colors ${
              activeTab === 'play_console'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Play Console Guide
          </button>
          <button
            onClick={() => setActiveTab('production_config')}
            className={`py-2.5 px-3 font-bold whitespace-nowrap border-b-2 transition-colors ${
              activeTab === 'production_config'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Required Production IDs
          </button>
          <button
            onClick={() => setActiveTab('payouts')}
            className={`py-2.5 px-3 font-bold whitespace-nowrap border-b-2 transition-colors ${
              activeTab === 'payouts'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Payouts & Monetization
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'checklist' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-blue-600 dark:text-blue-400" />
                <p>
                  Tick items as you configure them in your Google developer accounts. Use this checklist to verify production readiness.
                </p>
              </div>

              {checklistItems.map(item => {
                const isChecked = !!checkedIds[item.id];
                return (
                  <div
                    key={item.id}
                    onClick={() => setCheckedIds(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      isChecked
                        ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/80 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 text-blue-600 flex-shrink-0">
                        {isChecked ? (
                          <CheckSquare className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                            {item.category}
                          </span>
                          {isChecked && (
                            <span className="text-[10px] font-bold text-emerald-600">
                              Configured
                            </span>
                          )}
                        </div>
                        <h4 className="text-sm font-bold">{item.title}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          {item.description}
                        </p>
                        <div className="mt-1.5 text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 p-1.5 rounded-lg border border-blue-200 dark:border-blue-900">
                          {item.actionRequired}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'admob' && (
            <div className="space-y-3.5 text-xs">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-amber-500" />
                AdMob Account Setup Required
              </h4>
              <p className="text-slate-500">
                Google AdMob accounts are registered and managed directly by the app developer. You must perform these manual steps:
              </p>
              <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 font-mono text-[11px]">
                {admobSteps.map((step, idx) => (
                  <div key={idx} className="p-1 text-slate-700 dark:text-slate-300">
                    {step}
                  </div>
                ))}
              </div>
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300">
                <strong>Policy Warning:</strong> Never click your own live AdMob ads during testing. Keep test IDs active until testing is complete.
              </div>
            </div>
          )}

          {activeTab === 'play_console' && (
            <div className="space-y-3.5 text-xs">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-500" />
                Google Play Console Setup Required
              </h4>
              <p className="text-slate-500">
                You must manually create and configure the application and subscriptions in your Play Developer Console:
              </p>
              <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 font-mono text-[11px]">
                {playConsoleSteps.map((step, idx) => (
                  <div key={idx} className="p-1 text-slate-700 dark:text-slate-300">
                    {step}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'production_config' && (
            <div className="space-y-3 text-xs">
              <h4 className="text-sm font-bold flex items-center gap-2">
                <Code className="w-4 h-4 text-emerald-500" />
                Required Production Configuration Placeholders
              </h4>
              <p className="text-slate-500">
                The application code separates Development Test IDs from Production IDs in <span className="font-mono text-blue-500">src/config/admob.config.ts</span> and <span className="font-mono text-blue-500">.env</span>:
              </p>
              <div className="p-3 rounded-xl bg-slate-900 text-slate-200 font-mono text-[11px] space-y-2 overflow-x-auto">
                <p># AI Backend Key (Injected on production server)</p>
                <p className="text-emerald-400">GEMINI_API_KEY="your-production-gemini-key"</p>
                <p className="pt-2"># AdMob Production Unit Placeholders</p>
                <p className="text-blue-300">ADMOB_APP_ID="{PRODUCTION_AD_UNIT_IDS.ADMOB_APP_ID}"</p>
                <p className="text-blue-300">ADMOB_BANNER_ID="{PRODUCTION_AD_UNIT_IDS.ADMOB_BANNER_ID}"</p>
                <p className="text-blue-300">ADMOB_INTERSTITIAL_ID="{PRODUCTION_AD_UNIT_IDS.ADMOB_INTERSTITIAL_ID}"</p>
                <p className="text-blue-300">ADMOB_REWARDED_ID="{PRODUCTION_AD_UNIT_IDS.ADMOB_REWARDED_ID}"</p>
                <p className="pt-2"># Google Play Subscription Product IDs</p>
                <p className="text-amber-300">writeai_premium_monthly ($4.99/month)</p>
                <p className="text-amber-300">writeai_premium_yearly ($39.99/year)</p>
              </div>
            </div>
          )}

          {activeTab === 'payouts' && (
            <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-500" />
                Legitimate Monetization & Developer Payouts
              </h4>
              <p>
                WriteAI is architected with two legitimate Google revenue streams. There are no fake in-app balances or simulated instant wallets:
              </p>
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                <h5 className="font-bold text-slate-900 dark:text-white">Revenue Stream 1: Google Play Premium Subscriptions</h5>
                <p className="text-[11px]">
                  All digital purchases are processed directly by Google Play. Revenue is deposited into your bank account through your linked <strong>Google Payments Merchant Profile</strong> on the 15th of each month, minus Google Play service fees (15%).
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                <h5 className="font-bold text-slate-900 dark:text-white">Revenue Stream 2: Google AdMob Advertising</h5>
                <p className="text-[11px]">
                  Ad impressions and completed rewarded videos generate ad revenue managed through your <strong>Google AdMob / AdSense</strong> account. Payouts are transferred automatically to your designated bank account once you meet the payment threshold ($100).
                </p>
              </div>

              <p className="text-[11px] text-slate-500">
                Neither WriteAI nor any AI tool can promise guaranteed earnings. Revenue depends strictly on your active user acquisition, ad demand, eCPM, and user subscription conversion.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
          <button
            onClick={() => {
              const fullExport = `WRITEAI PRODUCTION DEPLOYMENT CHECKLIST\n\n` +
                checklistItems.map(c => `[ ] ${c.title} -> ${c.actionRequired}`).join('\n') +
                `\n\nADMOB SETUP STEPS:\n` + admobSteps.join('\n') +
                `\n\nPLAY CONSOLE SETUP STEPS:\n` + playConsoleSteps.join('\n');
              copyText(fullExport, 'all');
            }}
            className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-white dark:hover:bg-slate-750 flex items-center gap-1.5"
          >
            {copiedKey === 'all' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Copied All Documentation!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Setup Guide</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-500 shadow-md"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
