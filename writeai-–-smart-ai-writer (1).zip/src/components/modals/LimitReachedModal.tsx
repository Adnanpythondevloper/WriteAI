import React from 'react';
import { AlertCircle, Gift, Crown, Clock, X } from 'lucide-react';
import { TrialStatus } from '../../types';

interface LimitReachedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWatchRewardedAd: () => void;
  onUpgradePremium: () => void;
  trialStatus: TrialStatus;
}

export const LimitReachedModal: React.FC<LimitReachedModalProps> = ({
  isOpen,
  onClose,
  onWatchRewardedAd,
  onUpgradePremium,
  trialStatus,
}) => {
  if (!isOpen) return null;

  const isPremium = trialStatus === 'PREMIUM_ACTIVE';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-900 dark:text-white relative animate-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mx-auto mb-3">
          <AlertCircle className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-black text-center mb-1">
          Daily limit reached
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 text-center mb-6">
          You have used all allotted AI writing generations for today.
        </p>

        <div className="space-y-3">
          {/* Option 1: Watch an ad for +1 generation (available for free/trial) */}
          {!isPremium && (
            <button
              onClick={() => {
                onClose();
                onWatchRewardedAd();
              }}
              className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-blue-200 dark:border-blue-900/50 hover:border-blue-500 text-left flex items-center justify-between group transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center flex-shrink-0 shadow-md">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    Watch an ad for +1 generation
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Watch a sponsored video to unlock 1 bonus generation immediately
                  </p>
                </div>
              </div>
            </button>
          )}

          {/* Option 2: Unlock Premium */}
          <button
            onClick={() => {
              onClose();
              onUpgradePremium();
            }}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-left flex items-center justify-between shadow-lg shadow-blue-500/20 hover:from-blue-700 hover:to-indigo-700 transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 text-white flex items-center justify-center flex-shrink-0">
                <Crown className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <p className="text-sm font-bold">Unlock Premium</p>
                <p className="text-[11px] text-blue-100">
                  Higher usage, all advanced writing tools, and 100% ad-free
                </p>
              </div>
            </div>
          </button>

          {/* Option 3: Wait until tomorrow */}
          <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 flex items-center gap-3 text-xs">
            <Clock className="w-5 h-5 text-slate-400 flex-shrink-0" />
            <div>
              <p className="font-semibold text-slate-700 dark:text-slate-300">
                Wait until tomorrow
              </p>
              <p className="text-[11px] text-slate-500">
                Daily limits reset automatically at midnight local time.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2.5 text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-center"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};
