import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Mail, Send, CheckCircle2 } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl max-h-[85vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col text-slate-900 dark:text-white">
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-base font-bold">Privacy Policy</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          <p className="font-semibold text-slate-900 dark:text-white">
            Effective Date: October 2026 | Application: WriteAI – Smart AI Writer (com.writeai.smartwriter)
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">1. Information We Collect</h4>
          <p>
            WriteAI is built with privacy-first principles. We do not require account registration to access basic app features. Content entered into the writing fields is transmitted securely via HTTPS exclusively to process your requested AI generation. We do not sell your personal data or writing drafts.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">2. Data Storage & Local Persistence</h4>
          <p>
            Your generated writing history, favorite items, and app settings are stored locally on your device. You may clear your history and favorites at any time through the application Settings.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">3. Google AdMob & Advertising</h4>
          <p>
            For free and trial users, this application uses Google AdMob to serve advertisements. AdMob may collect and process device identifiers, advertising IDs, and non-sensitive diagnostic data in compliance with Google Play Policies and GDPR/CCPA regulations. Premium subscribers receive a 100% ad-free experience.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">4. Google Play Subscriptions</h4>
          <p>
            Financial transactions and payment credentials are processed securely and directly by Google Play. WriteAI never accesses or stores your credit card details or bank credentials.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">5. Contact Information</h4>
          <p>
            If you have questions or data privacy requests, contact our Data Privacy Officer at: <strong>privacy@writeai.com</strong>.
          </p>
        </div>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-right">
          <button
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export const TermsOfServiceModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl max-h-[85vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col text-slate-900 dark:text-white">
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-base font-bold">Terms of Service</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          <p className="font-semibold text-slate-900 dark:text-white">
            Application: WriteAI – Smart AI Writer (Package: com.writeai.smartwriter)
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">1. Acceptable Use</h4>
          <p>
            WriteAI is an AI-assisted writing tool for professional, personal, and educational productivity. You agree not to generate hate speech, fraudulent documents, malware, illegal harassment, or deceptive impersonation.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">2. 30-Day Free Trial Policy</h4>
          <p>
            New users receive 30 calendar days of free trial access starting from first activation. During the trial period, access is subject to generous daily limits. When the 30-day period expires, users may continue on the limited Free Plan or subscribe to WriteAI Premium. Users are never automatically billed upon trial expiration.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">3. Google Play Subscription Billing & Cancellation</h4>
          <p>
            WriteAI Premium offers Monthly ($4.99) and Annual ($39.99) auto-renewing subscriptions processed via Google Play Billing. Subscriptions renew automatically unless cancelled in your Google Play Store account settings at least 24 hours prior to the conclusion of the billing cycle. You may cancel anytime via Google Play Subscriptions.
          </p>

          <h4 className="font-bold text-slate-900 dark:text-white text-sm">4. Disclaimer of AI Output</h4>
          <p>
            AI-generated content should be reviewed by the user prior to publication, distribution, or professional submission. WriteAI makes no warranty regarding absolute accuracy of factual data and does not invent resume credentials not provided by the user.
          </p>
        </div>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-right">
          <button
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};

export const ContactSupportModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setEmail('');
      setMessage('');
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-slate-900 dark:text-white relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold">Contact Support</h3>
            <p className="text-xs text-slate-500">support@writeai.com</p>
          </div>
        </div>

        {sent ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold">Message Received</h4>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              Thank you! Our Android engineering support team will respond within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Your Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                How can we assist you?
              </label>
              <textarea
                required
                rows={4}
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Describe your issue, feedback, or subscription question..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-[11px] text-slate-500">
              App Version: 1.0.0 (Build 1) • Package: com.writeai.smartwriter
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Message</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
