import React, { useState, useEffect } from 'react';
import { ACTIVE_AD_IDS } from '../../config/admob.config';
import { X, ExternalLink, Zap } from 'lucide-react';

interface InterstitialAdModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InterstitialAdModal: React.FC<InterstitialAdModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(4);

  useEffect(() => {
    if (!isOpen) {
      setSecondsLeft(4);
      return;
    }

    const timer = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 text-white overflow-hidden shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/80 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold text-[10px]">
              AdMob Interstitial Ad
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ID: ...{ACTIVE_AD_IDS.ADMOB_INTERSTITIAL_ID.slice(-6)}
            </span>
          </div>

          <div>
            {secondsLeft > 0 ? (
              <span className="text-[11px] font-semibold text-slate-400 px-2 py-0.5 rounded-full bg-slate-800">
                Close in {secondsLeft}s
              </span>
            ) : (
              <button
                onClick={onClose}
                className="px-2.5 py-0.5 rounded-full bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs flex items-center gap-1 transition-colors"
              >
                Close <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-500/20">
            <Zap className="w-8 h-8 text-white" />
          </div>

          <h3 className="text-lg font-bold mb-1">Android Developer Showcase</h3>
          <p className="text-xs text-slate-400 mb-6">
            Build high performance apps using Material 3 and modern AI tools.
          </p>

          <a
            href="https://developer.android.com"
            target="_blank"
            rel="noreferrer"
            className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            Learn More <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
};
