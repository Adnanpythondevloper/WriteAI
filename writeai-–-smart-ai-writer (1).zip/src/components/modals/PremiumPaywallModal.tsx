import React, { useState } from 'react';
import {
  Crown,
  CheckCircle2,
  X,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  Globe,
} from 'lucide-react';
import {
  BILLING_PRODUCT_MONTHLY,
  BILLING_PRODUCT_YEARLY,
  SUPPORTED_LOCALIZED_CURRENCIES,
} from '../../config/billing.config';
import { SubscriptionProduct, TrialStatus } from '../../types';
import { BillingManager } from '../../services/BillingManager';
import { StorageManager } from '../../services/StorageManager';
import { GooglePlayBillingSheet } from './GooglePlayBillingSheet';

interface PremiumPaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  trialStatus: TrialStatus;
  daysRemaining: number;
  onContinueFree: () => void;
  onShowPrivacy: () => void;
  onShowTerms: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const PremiumPaywallModal: React.FC<PremiumPaywallModalProps> = ({
  isOpen,
  onClose,
  trialStatus,
  daysRemaining,
  onContinueFree,
  onShowPrivacy,
  onShowTerms,
  onShowToast,
}) => {
  const [selectedProduct, setSelectedProduct] = useState<SubscriptionProduct>(
    BILLING_PRODUCT_YEARLY
  );
  const [showCheckoutSheet, setShowCheckoutSheet] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const settings = StorageManager.getSettings();
  const [currentCurrency, setCurrentCurrency] = useState(settings.simulatedCurrency);

  if (!isOpen) return null;

  const isTrialEnded =
    trialStatus === 'TRIAL_EXPIRED' || trialStatus === 'FREE_LIMITED';
  const isTrialActive = trialStatus === 'TRIAL_ACTIVE';
  const isPremium = trialStatus === 'PREMIUM_ACTIVE';

  const handleCurrencyChange = (code: string) => {
    setCurrentCurrency(code);
    settings.simulatedCurrency = code;
    StorageManager.saveSettings(settings);
  };

  const handleRestorePurchases = async () => {
    setIsRestoring(true);
    try {
      const res = await BillingManager.restorePurchases();
      if (res.restored) {
        onShowToast(res.message, 'success');
        onClose();
      } else {
        onShowToast(res.message, 'info');
      }
    } finally {
      setIsRestoring(false);
    }
  };

  const handlePurchaseSuccess = () => {
    onShowToast('Welcome to WriteAI Premium! All features unlocked.', 'success');
  };

  const benefits = [
    'Substantially higher AI fair-use generation limits',
    'Full access to all 9 tools including Blog, CV & Cover Letter',
    'Completely ad-free experience (No banners, interstitials, or rewards)',
    'Generate comprehensive long-form content & articles',
    'Multi-language writing across 9 global languages',
    'Priority high-speed response processing',
    'Unlimited cloud history and favorite exports',
  ];

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
        <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto relative text-slate-900 dark:text-white">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Hero Banner */}
          <div className="relative bg-gradient-to-br from-blue-700 via-indigo-700 to-sky-600 p-6 sm:p-8 text-white text-center overflow-hidden">
            <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10 blur-2xl pointer-events-none" />
            <div className="absolute -left-8 -bottom-8 w-32 h-32 rounded-full bg-blue-400/20 blur-2xl pointer-events-none" />

            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md shadow-inner mb-3 border border-white/20">
              <Crown className="w-8 h-8 text-amber-300 fill-amber-300" />
            </div>

            <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-1.5">
              Unlock WriteAI Premium
            </h2>

            {isTrialEnded ? (
              <div className="inline-block px-3 py-1 rounded-full bg-rose-500/30 border border-rose-300/40 text-xs font-semibold text-rose-100 mb-2">
                Your 30-day free access has ended.
              </div>
            ) : isTrialActive ? (
              <p className="text-xs sm:text-sm text-blue-100 font-medium max-w-sm mx-auto">
                30 days free access active ({daysRemaining} days remaining). Upgrade anytime to guarantee uninterrupted executive writing.
              </p>
            ) : isPremium ? (
              <div className="inline-block px-3 py-1 rounded-full bg-emerald-500/30 border border-emerald-300/40 text-xs font-bold text-emerald-100 mb-2">
                ✓ Premium Plan Active
              </div>
            ) : (
              <p className="text-xs sm:text-sm text-blue-100 max-w-sm mx-auto">
                Supercharge your writing with unlimited professional tools and zero distractions.
              </p>
            )}
          </div>

          {/* Body */}
          <div className="p-5 sm:p-6 space-y-5">
            {/* Currency Selector for Global Testing */}
            <div className="flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                <Globe className="w-3.5 h-3.5 text-blue-500" />
                <span>Google Play Region / Currency:</span>
              </div>
              <select
                value={currentCurrency}
                onChange={e => handleCurrencyChange(e.target.value)}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 font-bold text-slate-800 dark:text-slate-200 text-xs focus:ring-1 focus:ring-blue-500"
              >
                {Object.keys(SUPPORTED_LOCALIZED_CURRENCIES).map(code => (
                  <option key={code} value={code}>
                    {code} ({SUPPORTED_LOCALIZED_CURRENCIES[code].symbol})
                  </option>
                ))}
              </select>
            </div>

            {/* Plan Cards */}
            <div className="grid grid-cols-2 gap-3">
              {/* Annual Plan */}
              <button
                type="button"
                onClick={() => setSelectedProduct(BILLING_PRODUCT_YEARLY)}
                className={`relative text-left p-3.5 sm:p-4 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                  selectedProduct.productId === BILLING_PRODUCT_YEARLY.productId
                    ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/40 shadow-md ring-2 ring-blue-500/20'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 hover:border-slate-300'
                }`}
              >
                <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[9px] font-black uppercase tracking-wider shadow">
                  SAVE 33%
                </span>
                <div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-400">
                    Annual Plan
                  </p>
                  <p className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white mt-0.5">
                    {BillingManager.getFormattedPrice(BILLING_PRODUCT_YEARLY)}
                  </p>
                  <p className="text-[10px] text-slate-500">Billed yearly</p>
                </div>
                <p className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold mt-2">
                  Best value for pros
                </p>
              </button>

              {/* Monthly Plan */}
              <button
                type="button"
                onClick={() => setSelectedProduct(BILLING_PRODUCT_MONTHLY)}
                className={`text-left p-3.5 sm:p-4 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                  selectedProduct.productId === BILLING_PRODUCT_MONTHLY.productId
                    ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/40 shadow-md ring-2 ring-blue-500/20'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 hover:border-slate-300'
                }`}
              >
                <div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-400">
                    Monthly Plan
                  </p>
                  <p className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white mt-0.5">
                    {BillingManager.getFormattedPrice(BILLING_PRODUCT_MONTHLY)}
                  </p>
                  <p className="text-[10px] text-slate-500">Billed monthly</p>
                </div>
                <p className="text-[10px] text-slate-500 mt-2">Flexible cancellation</p>
              </button>
            </div>

            {/* Benefits List */}
            <div className="space-y-2 py-1">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Premium Included Benefits:
              </p>
              {benefits.map((b, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <span>{b}</span>
                </div>
              ))}
            </div>

            {/* Subscribe CTA Button */}
            <div className="space-y-2.5 pt-1">
              <button
                onClick={() => setShowCheckoutSheet(true)}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-xl shadow-blue-500/25 flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  Start Premium •{' '}
                  {BillingManager.getFormattedPrice(selectedProduct)}
                  {BillingManager.getPeriodSuffix(selectedProduct)}
                </span>
              </button>

              {isTrialEnded && (
                <button
                  onClick={() => {
                    onContinueFree();
                    onClose();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-center"
                >
                  Continue with Free Plan (Limited 3 daily generations)
                </button>
              )}
            </div>

            {/* Secondary Actions & Google Play Disclosures */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-center space-y-2">
              <div className="flex items-center justify-center gap-4 text-xs font-medium text-slate-500 dark:text-slate-400">
                <button
                  onClick={handleRestorePurchases}
                  disabled={isRestoring}
                  className="hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-1"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRestoring ? 'animate-spin' : ''}`} />
                  <span>Restore Purchases</span>
                </button>
                <span>•</span>
                <button
                  onClick={onShowPrivacy}
                  className="hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Privacy Policy
                </button>
                <span>•</span>
                <button
                  onClick={onShowTerms}
                  className="hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Terms of Service
                </button>
              </div>

              <p className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight">
                Subscription renews automatically unless canceled at least 24 hours before the end of the current period in your Google Play Store Account Settings. No automatic charges occur without your Google Play confirmation.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Google Play Billing bottom sheet checkout */}
      <GooglePlayBillingSheet
        isOpen={showCheckoutSheet}
        product={selectedProduct}
        onClose={() => setShowCheckoutSheet(false)}
        onPurchaseSuccess={handlePurchaseSuccess}
      />
    </>
  );
};
