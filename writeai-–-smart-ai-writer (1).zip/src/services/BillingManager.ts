import {
  BILLING_PRODUCT_MONTHLY,
  BILLING_PRODUCT_YEARLY,
  SUBSCRIPTION_PRODUCTS,
  SUPPORTED_LOCALIZED_CURRENCIES,
} from '../config/billing.config';
import { SubscriptionProduct } from '../types';
import { StorageManager } from './StorageManager';
import { TrialManager } from './TrialManager';

export type BillingResponseCode =
  | 'OK'
  | 'USER_CANCELED'
  | 'SERVICE_UNAVAILABLE'
  | 'BILLING_UNAVAILABLE'
  | 'ITEM_UNAVAILABLE'
  | 'DEVELOPER_ERROR'
  | 'ERROR'
  | 'ITEM_ALREADY_OWNED';

export interface BillingPurchaseResult {
  responseCode: BillingResponseCode;
  success: boolean;
  message: string;
  orderId?: string;
}

export type BillingListener = () => void;

export class BillingManager {
  private static listeners: Set<BillingListener> = new Set();

  static subscribe(fn: BillingListener): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  static notify(): void {
    this.listeners.forEach(fn => fn());
  }

  static getProducts(): SubscriptionProduct[] {
    return SUBSCRIPTION_PRODUCTS;
  }

  static getFormattedPrice(product: SubscriptionProduct): string {
    const settings = StorageManager.getSettings();
    const currency =
      SUPPORTED_LOCALIZED_CURRENCIES[settings.simulatedCurrency] ||
      SUPPORTED_LOCALIZED_CURRENCIES.USD;
    return currency.format(product.priceUSD);
  }

  static getPeriodSuffix(product: SubscriptionProduct): string {
    return product.billingPeriod === 'yearly' ? '/year' : '/month';
  }

  static isNativeBillingClientAvailable(): boolean {
    const win = window as any;
    return !!(win.Capacitor?.Plugins?.PlayBilling || win.AndroidBillingBridge);
  }

  /**
   * Google Play Billing Purchase Flow
   * Communicates with Google Play client and verifies purchase token via backend /api/billing/verify.
   * Never unlocks Premium without verified server response.
   */
  static async startPurchaseFlow(
    productId: string,
    testLicenseToken?: string
  ): Promise<BillingPurchaseResult> {
    const userId = StorageManager.getUserId();
    const win = window as any;

    try {
      let purchaseToken = testLicenseToken;

      // 1. If running inside native Android runtime with Google Play Billing plugin
      if (this.isNativeBillingClientAvailable()) {
        const billingPlugin = win.Capacitor?.Plugins?.PlayBilling || win.AndroidBillingBridge;
        const playResult = await billingPlugin.launchBillingFlow({
          productId,
          type: 'subs',
        });

        if (playResult.responseCode === 'USER_CANCELED') {
          return {
            responseCode: 'USER_CANCELED',
            success: false,
            message: 'Purchase was cancelled in Google Play.',
          };
        }

        if (playResult.responseCode !== 'OK' || !playResult.purchaseToken) {
          return {
            responseCode: playResult.responseCode || 'ERROR',
            success: false,
            message: playResult.message || 'Google Play Billing returned an error.',
          };
        }

        purchaseToken = playResult.purchaseToken;
      }

      // If in sandbox mode without a test license token, require explicit token
      if (!purchaseToken) {
        return {
          responseCode: 'DEVELOPER_ERROR',
          success: false,
          message:
            'A valid Google Play purchase token is required. In Android production, Google Play automatically injects this token.',
        };
      }

      // 2. Transmit purchase token to secure backend for server-side Google Play Developer API verification
      const verifyRes = await fetch('/api/billing/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          packageName: 'com.writeai.smartwriter',
          productId,
          purchaseToken,
        }),
      });

      if (!verifyRes.ok) {
        const errJson = await verifyRes.json().catch(() => ({}));
        return {
          responseCode: 'ERROR',
          success: false,
          message: errJson.error || 'Server rejected subscription verification token.',
        };
      }

      const verifyData = await verifyRes.json();

      if (verifyData.verified && verifyData.entitlement === 'premium') {
        const planId = productId === BILLING_PRODUCT_YEARLY.productId ? 'yearly' : 'monthly';
        TrialManager.activatePremium(verifyData.expiryDate, planId);
        this.notify();
        return {
          responseCode: 'OK',
          success: true,
          message: 'Premium subscription successfully verified with Google Play!',
          orderId: verifyData.orderId,
        };
      } else {
        return {
          responseCode: 'ERROR',
          success: false,
          message: verifyData.message || 'Google Play purchase verification failed.',
        };
      }
    } catch (error: any) {
      console.error('Google Play purchase flow error', error);
      return {
        responseCode: 'ERROR',
        success: false,
        message: error.message || 'Network error during Google Play verification.',
      };
    }
  }

  /**
   * Restore Purchases:
   * Queries Google Play / secure backend for existing active subscriptions for this Google account.
   * If none exists, refuses to activate Premium.
   */
  static async restorePurchases(): Promise<{ restored: boolean; message: string }> {
    try {
      const userId = StorageManager.getUserId();
      const res = await fetch('/api/billing/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.restored && data.entitlement === 'premium') {
          const planId =
            data.record?.productId === BILLING_PRODUCT_YEARLY.productId ? 'yearly' : 'monthly';
          TrialManager.activatePremium(data.record.expiryDate, planId);
          this.notify();
          return {
            restored: true,
            message: data.message || 'Active WriteAI Premium subscription restored.',
          };
        } else {
          return {
            restored: false,
            message: data.message || 'No active Google Play subscription found for this account.',
          };
        }
      }
    } catch {
      // Offline fallback
    }

    // Verify local status
    const state = TrialManager.getState();
    if (state.isPremium && state.premiumExpiryDate && state.premiumExpiryDate > Date.now()) {
      return {
        restored: true,
        message: 'Active WriteAI Premium subscription verified.',
      };
    }

    return {
      restored: false,
      message: 'No active Google Play subscription was found for this Google account.',
    };
  }

  static cancelSubscription(): void {
    TrialManager.cancelPremium();
    this.notify();
  }
}
