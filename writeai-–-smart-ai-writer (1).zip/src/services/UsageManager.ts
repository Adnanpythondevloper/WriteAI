import { DailyUsage } from '../types';
import { StorageManager } from './StorageManager';
import { TrialManager } from './TrialManager';

export const LIMITS = {
  TRIAL_DAILY_LIMIT: 20,
  FREE_DAILY_LIMIT: 3,
  PREMIUM_DAILY_LIMIT: 150,
};

export class UsageManager {
  private static serverRemaining: number | null = null;
  private static serverDailyLimit: number | null = null;

  private static getTodayKey(): string {
    const d = new Date();
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(
      d.getUTCDate()
    ).padStart(2, '0')}`;
  }

  static getUsage(): DailyUsage {
    const today = this.getTodayKey();
    const current = StorageManager.getDailyUsage();

    if (!current || current.dateString !== today) {
      const fresh: DailyUsage = {
        dateString: today,
        generationsCount: 0,
        bonusGenerations: 0,
      };
      StorageManager.saveDailyUsage(fresh);
      return fresh;
    }

    return current;
  }

  static setServerUsage(remaining: number, limit?: number): void {
    this.serverRemaining = remaining;
    if (typeof limit === 'number') {
      this.serverDailyLimit = limit;
    }
  }

  static getDailyLimit(): number {
    if (typeof this.serverDailyLimit === 'number') {
      return this.serverDailyLimit;
    }
    const trialState = TrialManager.getState();
    if (trialState.status === 'PREMIUM_ACTIVE') {
      return LIMITS.PREMIUM_DAILY_LIMIT;
    }
    if (trialState.status === 'TRIAL_ACTIVE') {
      return LIMITS.TRIAL_DAILY_LIMIT;
    }
    return LIMITS.FREE_DAILY_LIMIT;
  }

  static getGenerationsRemaining(): number {
    // If we have verified server authority, return it
    if (typeof this.serverRemaining === 'number') {
      return Math.max(0, this.serverRemaining);
    }
    const usage = this.getUsage();
    const baseLimit = this.getDailyLimit();
    const totalAllowed = baseLimit + (usage.bonusGenerations || 0);
    const remaining = totalAllowed - usage.generationsCount;
    return Math.max(0, remaining);
  }

  static canGenerate(): boolean {
    return this.getGenerationsRemaining() > 0;
  }

  static recordGeneration(serverRemaining?: number): boolean {
    const usage = this.getUsage();
    usage.generationsCount += 1;
    if (typeof serverRemaining === 'number') {
      this.serverRemaining = serverRemaining;
      const baseLimit = this.getDailyLimit();
      const totalAllowed = baseLimit + (usage.bonusGenerations || 0);
      usage.generationsCount = Math.max(0, totalAllowed - serverRemaining);
    } else if (typeof this.serverRemaining === 'number') {
      this.serverRemaining = Math.max(0, this.serverRemaining - 1);
    }
    StorageManager.saveDailyUsage(usage);
    return true;
  }

  static addBonusGenerationFromAd(newRemaining?: number): number {
    const usage = this.getUsage();
    usage.bonusGenerations = (usage.bonusGenerations || 0) + 1;
    if (typeof newRemaining === 'number') {
      this.serverRemaining = newRemaining;
      const baseLimit = this.getDailyLimit();
      usage.bonusGenerations = Math.max(0, newRemaining + usage.generationsCount - baseLimit);
    } else if (typeof this.serverRemaining === 'number') {
      this.serverRemaining += 1;
    }
    StorageManager.saveDailyUsage(usage);
    return this.getGenerationsRemaining();
  }

  // Developer & QA testing helper
  static resetDailyUsageForTesting(): void {
    const today = this.getTodayKey();
    this.serverRemaining = null;
    this.serverDailyLimit = null;
    StorageManager.saveDailyUsage({
      dateString: today,
      generationsCount: 0,
      bonusGenerations: 0,
    });
  }

  static exhaustDailyUsageForTesting(): void {
    const today = this.getTodayKey();
    const limit = this.getDailyLimit();
    this.serverRemaining = 0;
    StorageManager.saveDailyUsage({
      dateString: today,
      generationsCount: limit,
      bonusGenerations: 0,
    });
  }
}
