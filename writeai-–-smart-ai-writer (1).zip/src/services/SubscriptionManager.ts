/**
 * SubscriptionManager
 *
 * Centralizes high-level subscription entitlement, billing states,
 * and expiration detection for WriteAI.
 */

import { SubscriptionProduct, TrialStatus } from '../types';
import { BillingManager, BillingPurchaseResult } from './BillingManager';
import { TrialManager } from './TrialManager';

export interface SubscriptionStatus {
  isPremium: boolean;
  statusText: string;
  planId?: 'monthly' | 'yearly';
  expiryDate?: number;
  daysRemaining?: number;
  autoRenewing: boolean;
}

export class SubscriptionManager {
  static getStatus(): SubscriptionStatus {
    const trial = TrialManager.getState();
    const isPremium = trial.status === 'PREMIUM_ACTIVE';

    if (isPremium) {
      const now = Date.now();
      const expiry = trial.premiumExpiryDate || 0;
      const daysRemaining = Math.max(0, Math.ceil((expiry - now) / (24 * 60 * 60 * 1000)));

      return {
        isPremium: true,
        statusText: 'Premium Active',
        planId: trial.planId,
        expiryDate: expiry,
        daysRemaining,
        autoRenewing: true,
      };
    }

    if (trial.status === 'TRIAL_ACTIVE') {
      const days = TrialManager.getDaysRemaining();
      return {
        isPremium: false,
        statusText: `${days} days left in trial`,
        daysRemaining: days,
        autoRenewing: false,
      };
    }

    if (trial.status === 'TRIAL_EXPIRED') {
      return {
        isPremium: false,
        statusText: 'Your free trial has ended',
        autoRenewing: false,
      };
    }

    return {
      isPremium: false,
      statusText: 'Free Plan',
      autoRenewing: false,
    };
  }

  static getProducts(): SubscriptionProduct[] {
    return BillingManager.getProducts();
  }

  static async purchase(
    product: SubscriptionProduct,
    testLicenseToken?: string
  ): Promise<BillingPurchaseResult> {
    return BillingManager.startPurchaseFlow(product.productId, testLicenseToken);
  }

  static async restore(): Promise<{ restored: boolean; message: string }> {
    return BillingManager.restorePurchases();
  }

  static checkExpiration(): boolean {
    const trial = TrialManager.getState();
    const now = Date.now();
    if (trial.isPremium && trial.premiumExpiryDate && now > trial.premiumExpiryDate) {
      TrialManager.cancelPremium();
      return true; // was expired
    }
    return false;
  }
}
