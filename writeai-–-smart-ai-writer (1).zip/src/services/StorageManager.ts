import { HistoryItem, TrialState, UserSettings, DailyUsage } from '../types';

const STORAGE_KEYS = {
  USER_ID: 'writeai_user_id_v1',
  SETTINGS: 'writeai_settings_v1',
  HISTORY: 'writeai_history_v1',
  TRIAL: 'writeai_trial_state_v1',
  USAGE: 'writeai_daily_usage_v1',
};

function generateStableUserId(): string {
  try {
    const existing = localStorage.getItem(STORAGE_KEYS.USER_ID);
    if (existing) return existing;
    const newId =
      'wai_' +
      Math.random().toString(36).substring(2, 10) +
      Date.now().toString(36);
    localStorage.setItem(STORAGE_KEYS.USER_ID, newId);
    return newId;
  } catch {
    return 'wai_local_' + Math.random().toString(36).substring(2, 10);
  }
}

export const DEFAULT_SETTINGS: UserSettings = {
  userId: generateStableUserId(),
  defaultTone: 'Professional',
  defaultLength: 'Medium',
  defaultLanguage: 'English',
  darkMode: 'light',
  hasCompletedOnboarding: false,
  simulatedCurrency: 'USD',
};

export class StorageManager {
  static getUserId(): string {
    return generateStableUserId();
  }

  static getSettings(): UserSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      const uid = this.getUserId();
      if (!data) return { ...DEFAULT_SETTINGS, userId: uid };
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data), userId: uid };
    } catch {
      return { ...DEFAULT_SETTINGS, userId: this.getUserId() };
    }
  }

  static saveSettings(settings: UserSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings to localStorage', e);
    }
  }

  static getHistory(): HistoryItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HISTORY);
      if (!data) return [];
      return JSON.parse(data);
    } catch {
      return [];
    }
  }

  static saveHistory(items: HistoryItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save history', e);
    }
  }

  static getTrialState(): TrialState | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TRIAL);
      if (!data) return null;
      const parsed = JSON.parse(data);
      if (!parsed || typeof parsed !== 'object') return null;

      // Ensure valid dates
      if (!parsed.trialStartDate || typeof parsed.trialStartDate !== 'number') {
        parsed.trialStartDate = Date.now();
        parsed.trialEndDate = parsed.trialStartDate + 30 * 24 * 60 * 60 * 1000;
      }

      // Guard against fake or unverified premium state
      if (parsed.isPremium) {
        if (!parsed.premiumExpiryDate || parsed.premiumExpiryDate <= Date.now()) {
          parsed.isPremium = false;
          parsed.status = Date.now() >= parsed.trialEndDate ? 'FREE_LIMITED' : 'TRIAL_ACTIVE';
          parsed.premiumExpiryDate = undefined;
          this.saveTrialState(parsed);
        }
      }

      return parsed;
    } catch {
      return null;
    }
  }

  static saveTrialState(state: TrialState): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TRIAL, JSON.stringify(state));
    } catch (e) {
      console.error('Failed to save trial state', e);
    }
  }

  static getDailyUsage(): DailyUsage | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USAGE);
      if (!data) return null;
      return JSON.parse(data);
    } catch {
      return null;
    }
  }

  static saveDailyUsage(usage: DailyUsage): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USAGE, JSON.stringify(usage));
    } catch (e) {
      console.error('Failed to save daily usage', e);
    }
  }

  static clearHistory(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.HISTORY);
    } catch (e) {
      console.error('Failed to clear history', e);
    }
  }

  static clearFavorites(): void {
    try {
      const items = this.getHistory().map(i => ({ ...i, isFavorite: false }));
      this.saveHistory(items);
    } catch (e) {
      console.error('Failed to clear favorites', e);
    }
  }
}
