import {
  ACTIVE_AD_IDS,
  ADMOB_POLICY_RULES,
  USE_PRODUCTION_ADMOB,
} from '../config/admob.config';
import { StorageManager } from './StorageManager';
import { TrialManager } from './TrialManager';
import { UsageManager } from './UsageManager';

export interface MobileAdsSdkStatus {
  isInitialized: boolean;
  isTestMode: boolean;
  appId: string;
  nativeBridgeAvailable: boolean;
}

export class AdsManager {
  private static isInitialized = false;
  private static lastInterstitialTime = 0;
  private static naturalActionCount = 0;

  /**
   * Initializes the Google Mobile Ads SDK
   */
  static async initialize(): Promise<MobileAdsSdkStatus> {
    if (this.isInitialized) {
      return this.getStatus();
    }

    try {
      // Check if native Capacitor / Android Google Mobile Ads plugin is available
      const win = window as any;
      if (win.Capacitor?.Plugins?.AdMob) {
        await win.Capacitor.Plugins.AdMob.initialize({
          requestTrackingAuthorization: true,
          testingDevices: ['EMULATOR'],
          initializeForTesting: !USE_PRODUCTION_ADMOB,
        });
      }
      this.isInitialized = true;
    } catch {
      // In web browser preview environment, initialize web ad manager
      this.isInitialized = true;
    }

    return this.getStatus();
  }

  static getStatus(): MobileAdsSdkStatus {
    const win = window as any;
    return {
      isInitialized: this.isInitialized,
      isTestMode: !USE_PRODUCTION_ADMOB,
      appId: ACTIVE_AD_IDS.ADMOB_APP_ID,
      nativeBridgeAvailable: !!win.Capacitor?.Plugins?.AdMob,
    };
  }

  /**
   * Whether ads should be served.
   * Premium users are 100% ad-free (no banner, no interstitial, no rewarded offers).
   */
  static isAdsEnabled(): boolean {
    const trial = TrialManager.getState();
    return !trial.isPremium;
  }

  static getActiveIds() {
    return ACTIVE_AD_IDS;
  }

  /**
   * Evaluates natural transition points (e.g. after navigating back from viewing 3 generated documents).
   * Strictly enforces AdMob policy rules:
   * - Never at app launch
   * - Never while typing
   * - Never before generation
   * - Never on every click
   * - Respects frequency capping
   */
  static shouldShowInterstitial(): boolean {
    if (!this.isAdsEnabled()) return false;

    this.naturalActionCount += 1;
    if (this.naturalActionCount < 3) return false;

    const now = Date.now();
    const intervalMs = ADMOB_POLICY_RULES.maxInterstitialFrequencySeconds * 1000;
    if (now - this.lastInterstitialTime < intervalMs) {
      return false;
    }

    return true;
  }

  static recordInterstitialShown(): void {
    this.lastInterstitialTime = Date.now();
    this.naturalActionCount = 0;
  }

  /**
   * Rewarded Ad Completion Callback:
   * Strictly validates that the user completed the full required viewing.
   * Notifies backend server and awards +1 generation.
   */
  static async grantRewardedAdBonus(): Promise<number> {
    if (!this.isAdsEnabled()) return UsageManager.getGenerationsRemaining();

    try {
      const userId = StorageManager.getUserId();
      const res = await fetch('/api/ads/reward-grant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          adUnitId: ACTIVE_AD_IDS.ADMOB_REWARDED_ID,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        return UsageManager.addBonusGenerationFromAd(data.generationsRemaining);
      }
    } catch {
      // Fallback local update if offline
    }

    return UsageManager.addBonusGenerationFromAd();
  }
}
