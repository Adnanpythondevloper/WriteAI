import { HistoryItem, ToolId, Tone, ContentLength, TargetLanguage } from '../types';
import { StorageManager } from './StorageManager';

export class HistoryManager {
  static getAll(): HistoryItem[] {
    return StorageManager.getHistory();
  }

  static addItem(params: {
    toolId: ToolId;
    toolName: string;
    title: string;
    content: string;
    tone: Tone;
    length: ContentLength;
    language: TargetLanguage;
    optionsSummary?: string;
  }): HistoryItem {
    const items = StorageManager.getHistory();
    const wordCount = params.content.trim().split(/\s+/).filter(Boolean).length;
    const newItem: HistoryItem = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      toolId: params.toolId,
      toolName: params.toolName,
      title: params.title || params.toolName,
      content: params.content,
      tone: params.tone,
      length: params.length,
      language: params.language,
      optionsSummary: params.optionsSummary,
      createdAt: Date.now(),
      isFavorite: false,
      wordCount,
    };

    const updated = [newItem, ...items].slice(0, 100); // Keep last 100 entries
    StorageManager.saveHistory(updated);
    return newItem;
  }

  static updateItem(id: string, newContent: string): void {
    const items = StorageManager.getHistory();
    const wordCount = newContent.trim().split(/\s+/).filter(Boolean).length;
    const updated = items.map(item =>
      item.id === id ? { ...item, content: newContent, wordCount } : item
    );
    StorageManager.saveHistory(updated);
  }

  static toggleFavorite(id: string): boolean {
    const items = StorageManager.getHistory();
    let newState = false;
    const updated = items.map(item => {
      if (item.id === id) {
        newState = !item.isFavorite;
        return { ...item, isFavorite: newState };
      }
      return item;
    });
    StorageManager.saveHistory(updated);
    return newState;
  }

  static deleteItem(id: string): void {
    const items = StorageManager.getHistory();
    const updated = items.filter(item => item.id !== id);
    StorageManager.saveHistory(updated);
  }

  static getFavorites(): HistoryItem[] {
    return StorageManager.getHistory().filter(item => item.isFavorite);
  }

  static search(query: string, toolFilter?: string): HistoryItem[] {
    const items = StorageManager.getHistory();
    const q = query.toLowerCase().trim();

    return items.filter(item => {
      const matchesTool = !toolFilter || toolFilter === 'all' || item.toolId === toolFilter;
      if (!matchesTool) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.content.toLowerCase().includes(q) ||
        item.toolName.toLowerCase().includes(q)
      );
    });
  }

  static clearAll(): void {
    StorageManager.clearHistory();
  }
}
