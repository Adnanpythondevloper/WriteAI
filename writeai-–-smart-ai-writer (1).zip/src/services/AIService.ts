import { AI_TOOLS } from '../config/tools.config';
import { AIGenerateRequest, AIGenerateResponse } from '../types';
import { UsageManager } from './UsageManager';

export class AIService {
  private static activeAbortController: AbortController | null = null;
  private static isGenerating = false;

  static isInFlight(): boolean {
    return this.isGenerating;
  }

  static cancelCurrentRequest(): void {
    if (this.activeAbortController) {
      this.activeAbortController.abort();
      this.activeAbortController = null;
      this.isGenerating = false;
    }
  }

  static async generate(req: AIGenerateRequest): Promise<AIGenerateResponse> {
    // 1. Check duplicate request
    if (this.isGenerating) {
      throw new Error('A generation request is already in progress. Please wait.');
    }

    // 2. Check offline mode
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      throw new Error(
        'Offline: No internet connection detected. Please check your network and try again.'
      );
    }

    // 3. Validate inputs
    const values = Object.values(req.inputs).filter(
      v => typeof v === 'string' && v.trim().length > 0
    );
    if (values.length === 0) {
      throw new Error('Please fill in at least one input field before generating.');
    }

    // 4. Verify usage limit
    if (!UsageManager.canGenerate()) {
      throw new Error(
        'You have reached your daily generation limit. Watch a short rewarded ad for +1 generation or upgrade to WriteAI Premium.'
      );
    }

    const tool = AI_TOOLS.find(t => t.id === req.toolId);
    const systemPromptGoal = tool?.systemPromptGoal || 'Generate high-quality writing.';

    this.isGenerating = true;
    this.activeAbortController = new AbortController();

    // 35s timeout
    const timeoutId = setTimeout(() => {
      if (this.activeAbortController) {
        this.activeAbortController.abort('Request timed out after 35 seconds.');
      }
    }, 35000);

    const userId = req.userId || (await import('./StorageManager.ts')).StorageManager.getUserId();

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: this.activeAbortController.signal,
        body: JSON.stringify({
          userId,
          toolId: req.toolId,
          title: req.title,
          inputs: req.inputs,
          tone: req.tone,
          length: req.length,
          language: req.language,
          systemPromptGoal,
        }),
      });

      clearTimeout(timeoutId);

      const contentType = response.headers.get('content-type') || '';
      const isJson = contentType.includes('application/json');

      if (!response.ok) {
        let errorMsg = `Server error (${response.status}): ${response.statusText}`;
        if (isJson) {
          try {
            const errData = await response.json();
            errorMsg = errData.error || errorMsg;
          } catch {
            // ignore
          }
        }
        throw new Error(errorMsg);
      }

      if (!isJson) {
        throw new Error(
          'AI server returned an unexpected response format. Please verify your backend server is running.'
        );
      }

      const data = await response.json();

      if (!data.text || typeof data.text !== 'string') {
        throw new Error('Received an invalid response format from the AI server.');
      }

      // Deduct 1 generation on client and sync with server-reported count
      UsageManager.recordGeneration(data.remaining);

      return {
        text: data.text,
        tokensEstimated: Math.round(data.text.length / 4),
        remaining: data.remaining,
      };
    } catch (error: any) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Generation cancelled or timed out. Please try again.');
      }
      throw error;
    } finally {
      this.isGenerating = false;
      this.activeAbortController = null;
    }
  }
}
