import { TrialState, TrialStatus } from '../types';
import { StorageManager } from './StorageManager';
import { UsageManager } from './UsageManager';

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export type TrialListener = () => void;

export class TrialManager {
  private static state: TrialState;
  private static listeners: Set<TrialListener> = new Set();

  static subscribe(fn: TrialListener): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  static notify(): void {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (e) {
        console.error('Error in TrialManager listener', e);
      }
    });
  }

  static initialize(): TrialState {
    const saved = StorageManager.getTrialState();
    const now = Date.now();

    if (!saved) {
      // First activation: start real 30-day free trial. NEVER default to Premium Active!
      const newState: TrialState = {
        trialStartDate: now,
        trialEndDate: now + THIRTY_DAYS_MS,
        status: 'TRIAL_ACTIVE',
        isPremium: false,
      };
      StorageManager.saveTrialState(newState);
      this.state = newState;
      this.syncWithServer();
      return newState;
    }

    // Refresh status based on current time
    this.state = { ...saved };
    this.recomputeStatus();
    this.syncWithServer();
    return this.state;
  }

  static async syncWithServer(): Promise<void> {
    try {
      const userId = StorageManager.getUserId();
      const trialStart = this.state?.trialStartDate || Date.now();
      const res = await fetch(
        `/api/user/status?userId=${encodeURIComponent(userId)}&trialStart=${trialStart}`
      );
      if (res.ok) {
        const data = await res.json();
        if (data && data.status) {
          // Server is authoritative source of truth
          this.state.trialStartDate = data.trialStartDate || this.state.trialStartDate;
          this.state.trialEndDate = data.trialEndDate || this.state.trialEndDate;
          this.state.status = data.status as TrialStatus;
          this.state.isPremium = Boolean(data.isPremium);
          this.state.premiumExpiryDate = data.premiumExpiryDate;
          this.state.planId = data.planId;

          // Sync usage manager with server authority
          if (typeof data.generationsRemaining === 'number') {
            UsageManager.setServerUsage(data.generationsRemaining, data.dailyLimit);
          }

          StorageManager.saveTrialState(this.state);
          this.notify();
        }
      }
    } catch {
      // Offline fallback: rely on local persistent trial calculation
    }
  }

  static getState(): TrialState {
    if (!this.state) {
      return this.initialize();
    }
    this.recomputeStatus();
    return this.state;
  }

  static recomputeStatus(): void {
    const now = Date.now();

    // If premium is active, verify expiration
    if (this.state.isPremium) {
      if (this.state.premiumExpiryDate && now > this.state.premiumExpiryDate) {
        this.state.isPremium = false;
        this.state.status = now >= this.state.trialEndDate ? 'FREE_LIMITED' : 'TRIAL_ACTIVE';
        this.state.premiumExpiryDate = undefined;
        StorageManager.saveTrialState(this.state);
      } else {
        this.state.status = 'PREMIUM_ACTIVE';
      }
      return;
    }

    // Check trial expiration
    if (now >= this.state.trialEndDate) {
      this.state.status = 'FREE_LIMITED';
      StorageManager.saveTrialState(this.state);
    } else {
      if (this.state.status !== 'FREE_LIMITED') {
        this.state.status = 'TRIAL_ACTIVE';
      }
    }
  }

  static getDaysRemaining(): number {
    const state = this.getState();
    if (state.isPremium) return 999;
    const now = Date.now();
    const diffMs = state.trialEndDate - now;
    if (diffMs <= 0) return 0;
    return Math.min(30, Math.ceil(diffMs / (24 * 60 * 60 * 1000)));
  }

  static getTrialBadgeText(): string {
    const state = this.getState();
    if (state.status === 'PREMIUM_ACTIVE') {
      return 'Premium Active';
    }
    if (state.status === 'TRIAL_ACTIVE') {
      const days = this.getDaysRemaining();
      return `${days} days left`;
    }
    if (state.status === 'TRIAL_EXPIRED') {
      return 'Trial Ended';
    }
    return 'Free Limited';
  }

  static getUrgencyReminder(): string | null {
    const days = this.getDaysRemaining();
    const state = this.getState();
    if (state.status !== 'TRIAL_ACTIVE') return null;

    if (days <= 1) return '1 day remaining – upgrade to keep unlimited tools';
    if (days <= 3) return '3 days remaining in your free trial';
    if (days <= 7) return '7 days remaining in your free trial';
    if (days <= 23 && days >= 20) return `${days} days remaining in your free trial`;
    return null;
  }

  static continueWithFreePlan(): void {
    const state = this.getState();
    state.status = 'FREE_LIMITED';
    state.isPremium = false;
    StorageManager.saveTrialState(state);
    this.state = state;
    this.notify();
  }

  static activatePremium(expiryDate: number, planId: 'monthly' | 'yearly'): void {
    const state = this.getState();
    state.isPremium = true;
    state.status = 'PREMIUM_ACTIVE';
    state.premiumExpiryDate = expiryDate;
    state.planId = planId;
    StorageManager.saveTrialState(state);
    this.state = state;
    this.notify();
  }

  static cancelPremium(): void {
    const state = this.getState();
    state.isPremium = false;
    state.status = Date.now() >= state.trialEndDate ? 'FREE_LIMITED' : 'TRIAL_ACTIVE';
    state.premiumExpiryDate = undefined;
    StorageManager.saveTrialState(state);
    this.state = state;
    this.notify();
  }

  // Developer & QA testing helper to simulate various subscription/trial days
  static async simulateDaysRemaining(days: number): Promise<void> {
    const now = Date.now();
    const state = this.getState();
    state.trialEndDate = now + days * 24 * 60 * 60 * 1000;
    state.isPremium = false;
    state.status = days > 0 ? 'TRIAL_ACTIVE' : 'FREE_LIMITED';
    StorageManager.saveTrialState(state);
    this.state = state;

    try {
      const userId = StorageManager.getUserId();
      await fetch('/api/user/simulate-trial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, daysLeft: days }),
      });
    } catch {
      // ignore
    }

    this.notify();
  }

  static async resetTrialToFull30Days(): Promise<void> {
    const now = Date.now();
    const state: TrialState = {
      trialStartDate: now,
      trialEndDate: now + THIRTY_DAYS_MS,
      status: 'TRIAL_ACTIVE',
      isPremium: false,
    };
    StorageManager.saveTrialState(state);
    this.state = state;
    UsageManager.resetDailyUsageForTesting();

    try {
      const userId = StorageManager.getUserId();
      await fetch('/api/user/simulate-trial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, daysLeft: 30 }),
      });
    } catch {
      // ignore
    }

    this.notify();
  }
}
