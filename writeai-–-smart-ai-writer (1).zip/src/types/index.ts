export type ToolId =
  | 'email_writer'
  | 'social_writer'
  | 'product_desc'
  | 'blog_writer'
  | 'cv_writer'
  | 'cover_letter'
  | 'rewrite_improve'
  | 'summarizer'
  | 'grammar_checker';

export type Tone =
  | 'Professional'
  | 'Friendly'
  | 'Formal'
  | 'Casual'
  | 'Persuasive'
  | 'Creative'
  | 'Simple';

export type ContentLength = 'Short' | 'Medium' | 'Long';

export type TargetLanguage =
  | 'English'
  | 'Spanish'
  | 'French'
  | 'German'
  | 'Italian'
  | 'Portuguese'
  | 'Arabic'
  | 'Urdu'
  | 'Hindi';

export type TrialStatus =
  | 'TRIAL_ACTIVE'
  | 'TRIAL_EXPIRED'
  | 'PREMIUM_ACTIVE'
  | 'FREE_LIMITED';

export interface HistoryItem {
  id: string;
  toolId: ToolId;
  toolName: string;
  title: string;
  content: string;
  tone: Tone;
  length: ContentLength;
  language: TargetLanguage;
  optionsSummary?: string;
  createdAt: number;
  isFavorite: boolean;
  wordCount: number;
}

export interface UserSettings {
  userId: string;
  defaultTone: Tone;
  defaultLength: ContentLength;
  defaultLanguage: TargetLanguage;
  darkMode: 'system' | 'light' | 'dark';
  hasCompletedOnboarding: boolean;
  simulatedCurrency: string;
}

export interface TrialState {
  trialStartDate: number;
  trialEndDate: number;
  status: TrialStatus;
  isPremium: boolean;
  premiumExpiryDate?: number;
  planId?: 'monthly' | 'yearly';
}

export interface DailyUsage {
  dateString: string;
  generationsCount: number;
  bonusGenerations: number;
}

export interface AIGenerateRequest {
  toolId: ToolId;
  title: string;
  inputs: Record<string, string>;
  tone: Tone;
  length: ContentLength;
  language: TargetLanguage;
  userId?: string;
}

export interface AIGenerateResponse {
  text: string;
  tokensEstimated?: number;
  remaining?: number;
}

export interface SubscriptionProduct {
  productId: string;
  name: string;
  billingPeriod: string;
  priceUSD: number;
  discountBadge?: string;
  description: string;
}
