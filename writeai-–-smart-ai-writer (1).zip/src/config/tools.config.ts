import { ToolId } from '../types';

export interface ToolField {
  id: string;
  label: string;
  type: 'text' | 'textarea' | 'select';
  placeholder?: string;
  helperText?: string;
  options?: string[];
  required?: boolean;
  rows?: number;
}

export interface ToolConfig {
  id: ToolId;
  name: string;
  tagline: string;
  iconName: string;
  category: 'Communication' | 'Marketing' | 'Career' | 'Editing';
  isPremiumOnlyPostTrial?: boolean;
  fields: ToolField[];
  systemPromptGoal: string;
}

export const AI_TOOLS: ToolConfig[] = [
  {
    id: 'email_writer',
    name: 'Email Writer',
    tagline: 'Draft high-impact professional, business, and follow-up emails in seconds.',
    iconName: 'Mail',
    category: 'Communication',
    isPremiumOnlyPostTrial: false,
    fields: [
      {
        id: 'emailType',
        label: 'Email Purpose / Type',
        type: 'select',
        options: [
          'Professional',
          'Business',
          'Job application',
          'Follow-up',
          'Customer support',
          'Complaint',
          'Thank-you',
          'Meeting',
          'Sales',
          'Cold email',
          'Friendly email',
        ],
        required: true,
      },
      {
        id: 'recipient',
        label: 'Recipient / Audience',
        type: 'text',
        placeholder: 'e.g., Hiring Manager, Client, Project Lead, Support Team',
      },
      {
        id: 'subject',
        label: 'Subject Line Idea (Optional)',
        type: 'text',
        placeholder: 'e.g., Quick check-in regarding Tuesday meeting proposal',
      },
      {
        id: 'keyPoints',
        label: 'Key Points or Message Details',
        type: 'textarea',
        placeholder: 'Enter the main points, request, deadlines, or context you want included...',
        required: true,
        rows: 4,
      },
      {
        id: 'callToAction',
        label: 'Desired Outcome / Call to Action',
        type: 'text',
        placeholder: 'e.g., Schedule a 15-minute call, confirm receipt, approve invoice',
      },
    ],
    systemPromptGoal:
      'Generate a complete, professionally formatted email with a crisp Subject line, salutation, body paragraphs structured for readability, and appropriate sign-off.',
  },
  {
    id: 'social_writer',
    name: 'Social Media Writer',
    tagline: 'Create engaging, viral posts tailored for top social platforms.',
    iconName: 'Share2',
    category: 'Marketing',
    isPremiumOnlyPostTrial: false,
    fields: [
      {
        id: 'platform',
        label: 'Target Platform',
        type: 'select',
        options: [
          'Instagram',
          'Facebook',
          'LinkedIn',
          'X/Twitter',
          'TikTok',
          'YouTube Community',
        ],
        required: true,
      },
      {
        id: 'topic',
        label: 'Post Topic or Core Message',
        type: 'textarea',
        placeholder: 'What is this post about? (e.g., Product launch announcement, industry insight, tips for productivity)',
        required: true,
        rows: 3,
      },
      {
        id: 'includeHashtags',
        label: 'Include Hashtags & Emojis?',
        type: 'select',
        options: ['Yes (Optimized & Relevant)', 'Subtle (Few)', 'No (Clean Text Only)'],
      },
      {
        id: 'callToAction',
        label: 'Call to Action (CTA)',
        type: 'text',
        placeholder: 'e.g., Link in bio, comment your thoughts, retweet',
      },
    ],
    systemPromptGoal:
      'Craft a native social media post respecting platform culture, algorithm dynamics, hook lines, whitespace formatting, and relevant hashtags if requested.',
  },
  {
    id: 'product_desc',
    name: 'Product Description',
    tagline: 'Write persuasive, high-converting copy for e-commerce listings.',
    iconName: 'ShoppingBag',
    category: 'Marketing',
    isPremiumOnlyPostTrial: true,
    fields: [
      {
        id: 'platform',
        label: 'Store / Marketplace',
        type: 'select',
        options: ['Amazon', 'Shopify', 'Etsy', 'Website', 'Online store'],
        required: true,
      },
      {
        id: 'productName',
        label: 'Product Name',
        type: 'text',
        placeholder: 'e.g., Ergonomic Memory Foam Neck Pillow',
        required: true,
      },
      {
        id: 'features',
        label: 'Key Features & Materials',
        type: 'textarea',
        placeholder: 'List 3-5 features (e.g., 100% cooling gel, breathable bamboo cover, washable, ergonomic contour)...',
        required: true,
        rows: 3,
      },
      {
        id: 'targetAudience',
        label: 'Target Audience / Pain Points Solved',
        type: 'text',
        placeholder: 'e.g., Frequent travelers, office workers with neck stiffness',
      },
    ],
    systemPromptGoal:
      'Generate a compelling product description highlighting benefits over features, structured with an irresistible hook, bullet points, sensory words, and buying impulse CTA.',
  },
  {
    id: 'blog_writer',
    name: 'Blog Writer',
    tagline: 'Generate complete, SEO-optimized articles with titles, headings, and meta tags.',
    iconName: 'BookOpen',
    category: 'Marketing',
    isPremiumOnlyPostTrial: true,
    fields: [
      {
        id: 'topic',
        label: 'Blog Topic / Title',
        type: 'text',
        placeholder: 'e.g., 7 Proven Remote Work Habits to Double Productivity',
        required: true,
      },
      {
        id: 'keywords',
        label: 'Target SEO Keywords',
        type: 'text',
        placeholder: 'e.g., remote work tips, daily productivity, home office routine',
      },
      {
        id: 'outline',
        label: 'Specific Subtopics / Sections (Optional)',
        type: 'textarea',
        placeholder: 'Specify key points or let AI create a comprehensive structure...',
        rows: 3,
      },
    ],
    systemPromptGoal:
      'Generate a complete, structured article including: 1. SEO Title, 2. Meta Description, 3. Engaging Introduction, 4. Detailed H2 and H3 body sections with actionable advice, and 5. Conclusion with Key Takeaways.',
  },
  {
    id: 'cv_writer',
    name: 'CV / Resume Writer',
    tagline: 'Craft professional summaries, bullet points, skills, and achievements.',
    iconName: 'FileText',
    category: 'Career',
    isPremiumOnlyPostTrial: true,
    fields: [
      {
        id: 'targetRole',
        label: 'Target Job Title & Industry',
        type: 'text',
        placeholder: 'e.g., Senior Full-Stack Engineer, Fintech Industry',
        required: true,
      },
      {
        id: 'userExperience',
        label: 'Your Actual Work Experience & Past Roles',
        type: 'textarea',
        placeholder: 'Provide your real background, companies, roles, and responsibilities. IMPORTANT: Provide facts only.',
        required: true,
        rows: 4,
        helperText: 'WriteAI strictly uses your provided background and will never fabricate past employers or credentials.',
      },
      {
        id: 'skills',
        label: 'Your Skills & Tools',
        type: 'text',
        placeholder: 'e.g., TypeScript, React, Node.js, AWS, Agile leadership',
      },
      {
        id: 'achievements',
        label: 'Key Real Achievements or Metrics',
        type: 'textarea',
        placeholder: 'e.g., Reduced latency by 35%, managed team of 5, launched mobile app with 50k users',
        rows: 2,
      },
    ],
    systemPromptGoal:
      'CRITICAL: Never invent qualifications, jobs, degrees, or achievements not provided by the user. Transform user notes into powerful executive resume sections: Professional Summary, Core Competencies, High-Impact Action Verb Experience Bullets (PAR format), and Skills list.',
  },
  {
    id: 'cover_letter',
    name: 'Cover Letter Writer',
    tagline: 'Tailor a compelling, persuasive cover letter for your dream application.',
    iconName: 'Award',
    category: 'Career',
    isPremiumOnlyPostTrial: true,
    fields: [
      {
        id: 'jobTitle',
        label: 'Job Title & Company Name',
        type: 'text',
        placeholder: 'e.g., Product Manager at Spotify',
        required: true,
      },
      {
        id: 'userBackground',
        label: 'Your Relevant Qualifications & Background',
        type: 'textarea',
        placeholder: 'Mention 2-3 genuine achievements, current role, or years of experience...',
        required: true,
        rows: 3,
      },
      {
        id: 'whyCompany',
        label: 'Why You Are Excited About This Specific Company',
        type: 'textarea',
        placeholder: 'e.g., I love your recent podcast initiative and mission to empower independent creators...',
        rows: 2,
      },
    ],
    systemPromptGoal:
      'Write a personalized, compelling cover letter that avoids generic clichés. Highlight authentic fit, problem-solving capability, and enthusiasm without inventing false credentials.',
  },
  {
    id: 'rewrite_improve',
    name: 'Rewrite & Improve',
    tagline: 'Enhance clarity, vocabulary, flow, and persuasion of any text.',
    iconName: 'Sparkles',
    category: 'Editing',
    isPremiumOnlyPostTrial: false,
    fields: [
      {
        id: 'textToRewrite',
        label: 'Original Text to Improve',
        type: 'textarea',
        placeholder: 'Paste the draft, paragraph, or message you want polished...',
        required: true,
        rows: 5,
      },
      {
        id: 'improvementGoal',
        label: 'Focus / Improvement Objective',
        type: 'select',
        options: [
          'Improve Clarity & Flow',
          'Make More Persuasive & Compelling',
          'Make More Executive & Professional',
          'Simplify & Make Concise',
          'Fix Awkward Phrasing',
        ],
        required: true,
      },
    ],
    systemPromptGoal:
      'Rewrite the provided text preserving its core meaning while dramatically enhancing prose quality, rhythm, and clarity according to the chosen objective.',
  },
  {
    id: 'summarizer',
    name: 'Summarizer',
    tagline: 'Condense long articles, reports, or transcripts into key takeaways.',
    iconName: 'ListOrdered',
    category: 'Editing',
    isPremiumOnlyPostTrial: false,
    fields: [
      {
        id: 'contentToSummarize',
        label: 'Content or Text to Summarize',
        type: 'textarea',
        placeholder: 'Paste the article, notes, email thread, or document here...',
        required: true,
        rows: 6,
      },
      {
        id: 'summaryFormat',
        label: 'Summary Format',
        type: 'select',
        options: [
          'Executive Summary + Key Bullet Points',
          'Quick 3-Sentence TL;DR',
          'Action Items & Decisions Only',
          'Comprehensive Outline',
        ],
        required: true,
      },
    ],
    systemPromptGoal:
      'Extract the essential insights and takeaways clearly and concisely according to the specified summary format, filtering out fluff.',
  },
  {
    id: 'grammar_checker',
    name: 'Grammar & Spell Checker',
    tagline: 'Fix grammatical errors, punctuation, spelling, and awkward syntax.',
    iconName: 'CheckCheck',
    category: 'Editing',
    isPremiumOnlyPostTrial: false,
    fields: [
      {
        id: 'textToCheck',
        label: 'Text to Check and Correct',
        type: 'textarea',
        placeholder: 'Paste text with potential typos or grammatical errors...',
        required: true,
        rows: 5,
      },
    ],
    systemPromptGoal:
      'Review text for spelling, punctuation, grammar, and syntax errors. Provide: 1. Polished Corrected Version, 2. Brief list of specific corrections made and why.',
  },
];
