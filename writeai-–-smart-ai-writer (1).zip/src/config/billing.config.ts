/**
 * Google Play Billing Configuration
 *
 * Package ID: com.writeai.smartwriter
 *
 * Requirements:
 * 1. Product IDs must match the in-app subscriptions configured in Google Play Console
 *    under Monetize -> Subscriptions.
 * 2. Prices are dynamically localized by Google Play Billing library at runtime based
 *    on the user's Google Play store country/currency.
 */

import { SubscriptionProduct } from '../types';

export const BILLING_PRODUCT_MONTHLY: SubscriptionProduct = {
  productId: 'writeai_premium_monthly',
  name: 'WriteAI Premium Monthly',
  billingPeriod: 'monthly',
  priceUSD: 4.99,
  description: 'Full access to all 9 AI tools, higher fair-use limit, priority generation & ad-free experience.',
};

export const BILLING_PRODUCT_YEARLY: SubscriptionProduct = {
  productId: 'writeai_premium_yearly',
  name: 'WriteAI Premium Annual',
  billingPeriod: 'yearly',
  priceUSD: 39.99,
  discountBadge: 'SAVE 33%',
  description: 'Full access to all 9 AI tools with maximum savings. Billed annually.',
};

export const SUBSCRIPTION_PRODUCTS = [
  BILLING_PRODUCT_MONTHLY,
  BILLING_PRODUCT_YEARLY,
];

// Supported Google Play Currencies with exchange simulation for testing worldwide regions
export interface LocalizedCurrency {
  code: string;
  symbol: string;
  multiplier: number;
  format: (amount: number) => string;
}

export const SUPPORTED_LOCALIZED_CURRENCIES: Record<string, LocalizedCurrency> = {
  USD: {
    code: 'USD',
    symbol: '$',
    multiplier: 1.0,
    format: (amt) => `$${amt.toFixed(2)}`,
  },
  EUR: {
    code: 'EUR',
    symbol: '€',
    multiplier: 0.92,
    format: (amt) => `€${(amt * 0.92).toFixed(2)}`,
  },
  GBP: {
    code: 'GBP',
    symbol: '£',
    multiplier: 0.79,
    format: (amt) => `£${(amt * 0.79).toFixed(2)}`,
  },
  CAD: {
    code: 'CAD',
    symbol: 'CA$',
    multiplier: 1.36,
    format: (amt) => `CA$${(amt * 1.36).toFixed(2)}`,
  },
  AUD: {
    code: 'AUD',
    symbol: 'AU$',
    multiplier: 1.52,
    format: (amt) => `AU$${(amt * 1.52).toFixed(2)}`,
  },
  INR: {
    code: 'INR',
    symbol: '₹',
    multiplier: 83.5,
    format: (amt) => `₹${Math.round(amt * 83.5)}`,
  },
  BRL: {
    code: 'BRL',
    symbol: 'R$',
    multiplier: 5.15,
    format: (amt) => `R$${(amt * 5.15).toFixed(2)}`,
  },
  JPY: {
    code: 'JPY',
    symbol: '¥',
    multiplier: 155.0,
    format: (amt) => `¥${Math.round(amt * 155.0)}`,
  },
};
