/**
 * Google Mobile Ads SDK (AdMob) Configuration
 *
 * Package ID: com.writeai.smartwriter
 *
 * Requirements & Policy:
 * 1. During development and testing, always use official Google AdMob TEST IDs.
 * 2. In production, insert real IDs obtained from https://admob.google.com.
 * 3. Never click live ads during testing to prevent AdMob account suspension.
 * 4. Production IDs must NEVER be used in development.
 */

export interface AdMobIds {
  ADMOB_APP_ID: string;
  ADMOB_BANNER_ID: string;
  ADMOB_INTERSTITIAL_ID: string;
  ADMOB_REWARDED_ID: string;
}

/**
 * ============================================================================
 * 1. OFFICIAL GOOGLE ADMOB SAMPLE TEST IDS (Android)
 * ============================================================================
 * Source: https://developers.google.com/admob/android/test-ads#sample_ad_units
 * Safe for development, testing, and Google Play pre-launch reports.
 * DO NOT EDIT OR REMOVE THESE TEST IDS.
 */
export const DEVELOPMENT_AD_UNIT_IDS: AdMobIds = {
  ADMOB_APP_ID: 'ca-app-pub-3940256099942544~3347511713',
  ADMOB_BANNER_ID: 'ca-app-pub-3940256099942544/6300978111',
  ADMOB_INTERSTITIAL_ID: 'ca-app-pub-3940256099942544/1033173712',
  ADMOB_REWARDED_ID: 'ca-app-pub-3940256099942544/5224354917',
};

// Convenient alias for development test IDs
export const TEST_AD_UNIT_IDS: AdMobIds = DEVELOPMENT_AD_UNIT_IDS;

/**
 * ============================================================================
 * 2. PRODUCTION ADMOB CONFIGURATION PLACEHOLDERS
 * ============================================================================
 * MANUAL SETUP INSTRUCTIONS (When ready for Google Play release):
 * 1. Sign in to your Google AdMob console: https://admob.google.com
 * 2. Add 'WriteAI – Smart AI Writer' (com.writeai.smartwriter) as an Android app.
 * 3. Create three ad units: Banner, Interstitial, and Rewarded.
 * 4. Replace the placeholder IDs below OR configure them via release environment variables:
 *    - VITE_ADMOB_APP_ID
 *    - VITE_ADMOB_BANNER_ID
 *    - VITE_ADMOB_INTERSTITIAL_ID
 *    - VITE_ADMOB_REWARDED_ID
 * 5. Update AndroidManifest.xml:
 *    <meta-data
 *      android:name="com.google.android.gms.ads.APPLICATION_ID"
 *      android:value="ca-app-pub-YOUR_REAL_APP_ID"/>
 */
export const PRODUCTION_AD_UNIT_IDS: AdMobIds = {
  // Production App ID placeholder (Format: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY)
  ADMOB_APP_ID:
    import.meta.env?.VITE_ADMOB_APP_ID || 'ca-app-pub-YOUR_PRODUCTION_APP_ID_HERE~0000000000',

  // Production Banner Ad Unit ID placeholder (Format: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY)
  ADMOB_BANNER_ID:
    import.meta.env?.VITE_ADMOB_BANNER_ID || 'ca-app-pub-YOUR_PRODUCTION_APP_ID_HERE/BANNER_ID_HERE',

  // Production Interstitial Ad Unit ID placeholder (Format: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY)
  ADMOB_INTERSTITIAL_ID:
    import.meta.env?.VITE_ADMOB_INTERSTITIAL_ID || 'ca-app-pub-YOUR_PRODUCTION_APP_ID_HERE/INTERSTITIAL_ID_HERE',

  // Production Rewarded Ad Unit ID placeholder (Format: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY)
  ADMOB_REWARDED_ID:
    import.meta.env?.VITE_ADMOB_REWARDED_ID || 'ca-app-pub-YOUR_PRODUCTION_APP_ID_HERE/REWARDED_ID_HERE',
};

/**
 * ============================================================================
 * 3. TEST / PRODUCTION MODE SWITCH
 * ============================================================================
 * - `isProduction: false` (Default) => Always uses Google official TEST IDs.
 * - `isProduction: true`           => Uses PRODUCTION_AD_UNIT_IDS.
 *
 * HOW TO SWITCH MODES:
 * - In Development & QA: Leave `isProduction: false` (or unset VITE_ADMOB_IS_PRODUCTION).
 * - For Google Play Production Release:
 *     Either set `VITE_ADMOB_IS_PRODUCTION=true` in build env,
 *     OR change `MANUAL_OVERRIDE_PRODUCTION = true` below.
 */
const MANUAL_OVERRIDE_PRODUCTION = true;

export const isProduction: boolean =
  MANUAL_OVERRIDE_PRODUCTION || import.meta.env?.VITE_ADMOB_IS_PRODUCTION === 'true';

// Backward compatibility alias used across existing codebase
export const USE_PRODUCTION_ADMOB: boolean = isProduction;

/**
 * Consolidated configuration object
 */
export const admobConfig = {
  isProduction,
  useProduction: USE_PRODUCTION_ADMOB,
  testIds: DEVELOPMENT_AD_UNIT_IDS,
  productionIds: PRODUCTION_AD_UNIT_IDS,
};

/**
 * ============================================================================
 * 4. RESOLVED ACTIVE AD UNIT IDS
 * ============================================================================
 * Automatically selects official Google TEST IDs when `isProduction` is false,
 * or configured production AdMob IDs when `isProduction` is true.
 */
export const ACTIVE_AD_IDS: AdMobIds = isProduction
  ? PRODUCTION_AD_UNIT_IDS
  : DEVELOPMENT_AD_UNIT_IDS;

export const ADMOB_POLICY_RULES = {
  isDevelopment: !isProduction,
  maxInterstitialFrequencySeconds: 90,
  rewardedAdDurationSeconds: 5,
  rewardedBonusCount: 1,
};
